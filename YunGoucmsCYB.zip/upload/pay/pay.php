<?php
	$b = 'a:4:{s:3:"oid";s:28:"o5VAis4NL2TMGV9hDdcFkmKuLJOY";s:12:"out_trade_no";s:18:"C14589108959085415";s:9:"total_fee";i:1000;s:3:"url";s:57:"http://m.689aigou.com/index.php/pay/wxpay_web_url/houtai/";}';
?>