/*TAB切换qq86131032-2016-04-13*/

 //$(function () {
//        var ie6 = /msie 6/i.test(navigator.userAgent)
//        , dv = $('#fixedMenu'), st;
//        dv.attr('otop', dv.offset().top); //存储原来的距离顶部的距离
//        $(window).scroll(function () {
//            st = Math.max(document.body.scrollTop || document.documentElement.scrollTop);
//            if (st >= parseInt(dv.attr('otop'))) {
//                if (ie6) {//IE6不支持fixed属性，所以只能靠设置position为absolute和top实现此效果
//                    dv.css({ position: 'absolute', top: st });
//                }
//                else if (dv.css('position') != 'fixed') dv.css({ 'position': 'fixed', top: '50px' , background: '#f4de2d'});
//            } else if (dv.css('position') != 'static') dv.css({ 'position': 'static' });
//        });
//    });
//	


//首页公告滚动
	
	var box=document.getElementById("div1"),can=true; 
box.innerHTML+=box.innerHTML; 
box.onmouseover=function(){can=false}; 
box.onmouseout=function(){can=true}; 
new function (){ 
var stop=box.scrollTop%30==0&&!can; 
if(!stop)box.scrollTop==parseInt(box.scrollHeight/2)?box.scrollTop=0:box.scrollTop++; 
setTimeout(arguments.callee,box.scrollTop%30?10:3000); 
}; 

//结束



	
function tempaa()
{	
	one.style.color ='#FFFFFF';
	//one.style.borderBottom = "2px solid #f4de2d";
	one.style.backgroundColor = "#c9355a";
	two.style.backgroundColor = "#ffffff";
	three.style.backgroundColor = "#ffffff";
	four.style.backgroundColor = "#ffffff";
	//five.style.borderBottom = "none";
	two.style.color ='#4c4948';
	three.style.color ='#4c4948';
	four.style.color ='#4c4948';
	//five.style.color ='#4c4948';
	renqi.style.display="block";
	tuijian.style.display="none";
	zuixin.style.display="none";
	//jiage_gao.style.display="none";
	//jiage_di.style.display="none";
}
function tempa()
{	
	renqi.style.display="none";
	two.style.color ='#FFFFFF';
	//two.style.borderBottom = "2px solid #f4de2d";   
	two.style.backgroundColor = "#c9355a";
	one.style.backgroundColor = "#ffffff";
	three.style.backgroundColor = "#ffffff";
	four.style.backgroundColor = "#ffffff";
	//five.style.borderBottom = "none";
	one.style.color ='#4c4948';
	three.style.color ='#4c4948';
	four.style.color ='#4c4948';
	//five.style.color ='#4c4948';
	tuijian.style.display="block";
	zuixin.style.display="none";
	//jiage_gao.style.display="none";
	//jiage_di.style.display="none";
}
function tempb()
{	
	renqi.style.display="none";
	three.style.color ='#FFFFFF';
	//three.style.borderBottom = "2px solid #f4de2d";
	three.style.backgroundColor = "#c9355a";
	one.style.backgroundColor = "#ffffff";
	two.style.backgroundColor = "#ffffff";
	four.style.backgroundColor = "#ffffff";
	//five.style.borderBottom = "none";
	one.style.color ='#4c4948';
	two.style.color ='#4c4948';
	four.style.color ='#4c4948';
	//five.style.color ='#4c4948';
	zuixin.style.display="block";
	tuijian.style.display="none";
	//jiage_gao.style.display="none";
//	jiage_di.style.display="none";
}

function tempc()
{	
	renqi.style.display="none";
	four.style.color ='#FFFFFF';
	//four.style.borderBottom = "2px solid #f4de2d";
	four.style.backgroundColor = "#c9355a";
	one.style.backgroundColor = "#f4de2d";
	three.style.backgroundColor = "#f4de2d";
	two.style.backgroundColor = "#f4de2d";
	//five.style.borderBottom = "none";
	//five.style.color ='#4c4948';
	one.style.color ='#4c4948';
	two.style.color ='#4c4948';
	three.style.color ='#4c4948';
	//jiage_di.style.display="block";
	tuijian.style.display="none";
	zuixin.style.display="none";
	//jiage_gao.style.display="none";
	
}
function tempd()
{	
	renqi.style.display="none";
	//four.style.color ='#4c4948';
	//five.style.color ='#f4de2d';
	//five.style.borderBottom = "2px solid #f4de2d";
	one.style.borderBottom = "#f4de2d";
	three.style.borderBottom = "#f4de2d";
	two.style.borderBottom = "#f4de2d";
	//four.style.borderBottom = "none";
	one.style.color ='#4c4948';
	two.style.color ='#4c4948';
	three.style.color ='#4c4948';
	//jiage_di.style.display="none";
	tuijian.style.display="none";
	zuixin.style.display="none";
	//jiage_gao.style.display="block";
}// JavaScript Document




function temp()

{

	if(xiaomii.style.display=="block")

{

	

xiaomii.style.display="none";

fixedMenu.style.display="block";

}

else

{

xiaomii.style.display="block";

fixedMenu.style.display="none";

}

	}

	

	function tempgz()

	{

		

		document.getElementById('guanzhu').style.display='block'

		document.getElementById('gn-menu').style.display='none'

		document.getElementById('footer_cxy').style.display='none'

		}

		function tempgb()

	{

		

		document.getElementById('guanzhu').style.display='none'

		document.getElementById('gn-menu').style.display='block'

		document.getElementById('footer_cxy').style.display='block'



		}

	

	function tempee()

	{

		document.getElementById('divDownApp').style.display='none'
		document.getElementById('guanzhu').style.display='block'

		document.getElementById('gn-menu').style.display='none'

		document.getElementById('footer_cxy').style.display='none'
		document.getElementById('haibao').style.marginTop="50px"

		}
		
		function tempgbe()

	{

		document.getElementById('divDownApp').style.display='none'
		document.getElementById('haibao').style.marginTop="50px"

		}
		function sck()

	{

		document.getElementById('scwz').style.display='block'
  //     document.getElementById('buy-container').style.display='block'

		}
	function scg()

	{

		document.getElementById('scwz').style.display='none'
   //    document.getElementById('buy-container').style.display='none'
		}

		