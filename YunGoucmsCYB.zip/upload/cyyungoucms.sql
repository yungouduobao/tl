/*
Navicat MySQL Data Transfer

Source Server         : 创业版
Source Server Version : 50557
Source Host           : 42.51.15.13:3306
Source Database       : cyyungoucms

Target Server Type    : MYSQL
Target Server Version : 50557
File Encoding         : 65001

Date: 2018-08-07 10:51:15
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `go_ad_area`
-- ----------------------------
DROP TABLE IF EXISTS `go_ad_area`;
CREATE TABLE `go_ad_area` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `width` smallint(6) unsigned DEFAULT NULL,
  `height` smallint(6) unsigned DEFAULT NULL,
  `des` varchar(255) DEFAULT NULL,
  `checked` tinyint(1) DEFAULT '0' COMMENT '1表示通过',
  PRIMARY KEY (`id`),
  KEY `checked` (`checked`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='广告位';

-- ----------------------------
-- Records of go_ad_area
-- ----------------------------
INSERT INTO `go_ad_area` VALUES ('1', '首页对联广告', '150', '300', '首页对联广告', '1');

-- ----------------------------
-- Table structure for `go_ad_data`
-- ----------------------------
DROP TABLE IF EXISTS `go_ad_data`;
CREATE TABLE `go_ad_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aid` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `type` char(10) DEFAULT NULL COMMENT 'code,text,img',
  `content` text,
  `checked` tinyint(1) DEFAULT '0' COMMENT '1表示通过',
  `addtime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='广告';

-- ----------------------------
-- Records of go_ad_data
-- ----------------------------
INSERT INTO `go_ad_data` VALUES ('1', '3', '测试', 'couplet', 'admanage/20160328/44911418097639.jpg,admanage/20160328/48076565097647.jpg', '0', '1459094400', '1522166400');

-- ----------------------------
-- Table structure for `go_admin`
-- ----------------------------
DROP TABLE IF EXISTS `go_admin`;
CREATE TABLE `go_admin` (
  `uid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `mid` tinyint(3) unsigned NOT NULL,
  `username` char(15) NOT NULL,
  `userpass` char(32) NOT NULL,
  `useremail` varchar(100) DEFAULT NULL,
  `addtime` int(10) unsigned DEFAULT NULL,
  `logintime` int(10) unsigned DEFAULT NULL,
  `loginip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='管理员表';

-- ----------------------------
-- Records of go_admin
-- ----------------------------
INSERT INTO `go_admin` VALUES ('1', '0', 'admin', '52c69e3a57331081823331c4e69d3f2e', null, null, '1533608812', '106.92.247.243');

-- ----------------------------
-- Table structure for `go_appoint`
-- ----------------------------
DROP TABLE IF EXISTS `go_appoint`;
CREATE TABLE `go_appoint` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shopid` int(10) unsigned NOT NULL COMMENT '商品期数id',
  `userid` int(10) unsigned NOT NULL COMMENT '中奖用户',
  `time` int(10) unsigned NOT NULL COMMENT '添加时间',
  `status` int(10) unsigned NOT NULL COMMENT '订单状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_appoint
-- ----------------------------

-- ----------------------------
-- Table structure for `go_article`
-- ----------------------------
DROP TABLE IF EXISTS `go_article`;
CREATE TABLE `go_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文章id',
  `cateid` char(30) NOT NULL COMMENT '文章父ID',
  `author` char(20) DEFAULT NULL,
  `title` char(100) NOT NULL COMMENT '标题',
  `title_style` varchar(100) DEFAULT NULL,
  `thumb` char(255) DEFAULT NULL,
  `picarr` text,
  `keywords` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `content` mediumtext COMMENT '内容',
  `hit` int(10) unsigned DEFAULT '0',
  `order` tinyint(3) unsigned DEFAULT NULL,
  `posttime` int(10) unsigned DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `cateid` (`cateid`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_article
-- ----------------------------
INSERT INTO `go_article` VALUES ('1', '2', 'admin', '了解商城', '', '', 'a:2:{i:0;s:0:\"\";i:1;s:0:\"\";}', '', '', '<p>云购夺宝商城是一种新型的网购模式，只需1块钱就有可能买到一件商品。云购夺宝商城网把一件商品平分成若干“等份”出售，每份1块钱，当一件商品所有“等份”售出后抽出一名幸运者，该幸运者即可获得此商品。<br/>规则：<br/>&nbsp;<br/>1、每件商品参考市场价平分成相应“等份”，每份1块钱，1份对应1个购买码。<br/>2、同一件商品可以购买多次或一次购买多份。<br/>&nbsp;<br/>3、当一件商品所有“等份”全部售出后计算出“幸运参与码”<br/>&nbsp;<br/>，拥有“幸运购买码”者即可获得此商品。<br/>&nbsp;<br/>4、幸运参与码计算方式：<br/>&nbsp;<br/>1）取该商品最后购买时间前网站所有商品100条购买时间记录（限时揭晓商品取截止时间前网站所有商品100条购买时间记录）。<br/>&nbsp;<br/>2）时间按时、分、秒、毫秒依次排列组成一组数值。<br/>&nbsp;<br/>3）将这100组数值之和除以商品总需参与人次后取余数，余数加上10,000,001即为“幸运购买码”。<br/>流程：<br/>1、挑选商品<br/>分类浏览或直接搜索商品，点击“立即参与”。<br/>2、支付1块钱<br/>通过在线支付平台，支付1块钱即购买1人次，获得1个“购买码”。同一件商品可购买多次或一次购买多份，购买的“购买码”越多，获得商品的几率越大。<br/>3、揭晓获得者<br/>当一件商品达到总参与人次，抽出1名商品获得者，云购夺宝商城网会通过手机短信或邮件通知您领取商品。<br/>注：<br/>1）商品揭晓后您可登录&quot;我的云购夺宝商城&quot;查询详情，未获得商品的用户不会收到短信或邮件通知；<br/>2）商品揭晓后，请及时登录&quot;我的云购夺宝商城&quot;完善个人资料，以便我们能够准确无误地为您配送商品。<br/>3）所有发送商品均不给予退款<br/>4、晒单分享<br/>晒出您收到的商品实物图片甚至您的靓照，说出您的购买心得，让大家一起分享您的快乐。<br/>在您收到商品后，您只需登录网站完成晒单，并通过审核，即可获得1000福分奖励。在您成功晒单后，您的晒单会出现在网站&quot;晒单分享&quot;区，与大家分享喜悦。</p><p><br/></p><p><br/></p>', '1411', '1', '1515052860');
INSERT INTO `go_article` VALUES ('2', '2', 'admin', '常见问题', '', '', 'a:0:{}', '', '', '<p><br/></p><p><span style=\"font-family: 宋体;\">&nbsp;</span></p><p><span style=\"font-family: 宋体;\">&nbsp;</span></p><p><span style=\"font-family: 宋体;\">1</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">、怎样查看我参与的商品有没有中？</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">商品计算结果公布之后，登录网站，进入</span></span><span style=\"font-family: 宋体;\">&quot;</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">我的用户中心</span></span><span style=\"font-family: 宋体;\">&quot;</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">，在</span></span><span style=\"font-family: 宋体;\">&quot;</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">我购买的商品</span></span><span style=\"font-family: 宋体;\">&quot;</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">中即可查询结果。</span></span></p><p><span style=\"font-family: 宋体;\">2</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">、每件获得了商品，我还需要支付其他费用吗？</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">不需要支付其他任何费用。</span></span></p><p><span style=\"font-family: 宋体;\">3</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">、当我获得商品以后我该做什么？</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">在您获得商品后您会收到站内信、短信和电子邮件的通知。在这之后，您必须在</span></span><span style=\"font-family: 宋体;\">“</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">我的用户中心</span></span><span style=\"font-family: 宋体;\">”</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">正确填写、真实的收货地址，完善或确认您的个人信息。我们会在您获得商品后</span></span><span style=\"font-family: 宋体;\">3</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">个工作日内通过电话方式与您取得联系。</span></span></p><p><span style=\"font-family: 宋体;\">4</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">、商品是正品吗？怎么保证？</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">我们承诺，所有商品</span></span><span style=\"font-family: 宋体;\">100%</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">正品，可享受厂家所提供的全国联保服务，享受商品的保修、换货和退货的义务（国家三包政策）。</span></span></p><p><span style=\"font-family: 宋体;\">5</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">、如何晒单分享？</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">在您收到商品后，登录网站，进入</span></span><span style=\"font-family: 宋体;\">&quot;</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">我的用户中心</span></span><span style=\"font-family: 宋体;\">&quot;</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">，在</span></span><span style=\"font-family: 宋体;\">“</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">晒单分享</span></span><span style=\"font-family: 宋体;\">”</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">区发布晒单信息，通过审核后，您还可获得</span></span><span style=\"font-family: 宋体;\">400-1500</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">福分奖励。在您成功晒单后，您的晒单会出现在网站</span></span><span style=\"font-family: 宋体;\">“</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">晒单分享</span></span><span style=\"font-family: 宋体;\">”</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">区，与大家分享喜悦。</span></span></p><p><span style=\"font-family: 宋体;\">6</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">、我收到的商品可以换货或者退货吗？</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">非质量问题，不在三包范围内，不给予退换货。</span></span></p><p><span style=\"font-family: 宋体;\">7</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">、进云购夺宝商城购物需要注意什么？</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">请务必正确填写真实有效的联系电话、收货地址以便在我们时能及时与您取得联系。</span></span></p><p><span style=\"font-family: 宋体;\">8</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">、网上银行充值未及时到帐怎么办？</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">网上支付未及时到帐可能有以下几个原因造成：</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">第一，由于网速或者支付接口等问题，支付数据没有及时传送到支付系统造成的；</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">第二，网速过慢，数据传输超时，使银行后台支付信息不能成功对接，导致银行交易成功而支付后台显示失败；</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">第三，在网上支付如果使用某些防火墙软件，有时会屏蔽银行接口的弹出窗口，这时会造成在银行那边被扣费，但在我们网站上显示尚没支付。但请您放心，每天我们都会根据银行系统的帐务明细清单对前一天的订单进行逐笔核对，如遇问题订单，我们会做手工添加。</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">建议反馈</span></span></p><p><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">如您对我们</span></span><span style=\"font-family: 宋体;\">“</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">帮助中心</span></span><span style=\"font-family: 宋体;\">”</span><span style=\"font-size: 12px;\"><span style=\"font-family: 宋体;\">的说明有任何疑问或建议请告诉我们</span></span></p><p><span style=\"font-family: 宋体;\">&nbsp;</span></p><p><span style=\"font-family: Calibri;\">&nbsp;</span></p><p><br/></p><p><br/></p>', '1255', '3', '1514793780');
INSERT INTO `go_article` VALUES ('3', '2', 'admin', '服务协议', '', '', 'a:0:{}', '', '', '<p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　欢迎您访问并使用充满互动乐趣的购物网站，作为为用户提供全新、有趣购物模式的互联网公司，云购夺宝通过在线网站为您提供各项相关服务。当使用云购夺宝的各项具体服务时，您和云购夺宝都将受到本服务协议所产生的制约，云购夺宝会不断推出新的服务，因此所有服务都将受此服务条款的制约。请您在注册前务必认真阅读此服务协议的内容并确认，如有任何疑问，应向云购夺宝咨询。一旦您确认本服务协议后，本服务协议即在用户和云购夺宝之间产生法律效力。您在注册过程中点击“同意以下条款提交注册信息”按钮即表示您完全接受本协议中的全部条款。随后按照页面给予的提示完成全部的注册步骤。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　云购夺宝将可能不定期的修改本服务协议的有关条款，并保留在必要时对此协议中的所有条款进行随时修改的权利。一旦协议内容有所修改，云购夺宝将会在网站重要页面或社区的醒目位置第一时间给予通知。如果您继续使用云购夺宝的服务，则视为您受协议的改动内容。如果不同意本站对协议内容所做的修改，云购夺宝会及时取消您的服务使用权限。本站保留随时修改或中断服务而不需告知用户的权利。本站行使修改或中断服务的权利，不需对用户或第三方负责。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　一、用户注册</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1、用户注册是指用户登录云购夺宝，按要求填写相关信息并确认同意本服务协议的过程。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2、云购夺宝用户必须是具有完全民事行为能力的自然人，或者是具有合法经营资格的实体组织。无民事行为能力人、限制民事行为能力人以及无经营或特定经营资格的组织不得注册为云购夺宝用户或超过其民事权利或行为能力范围与云购夺宝进行交易，如与云购夺宝进行交易的，则服务协议自始无效，云购夺宝有权立即停止与该用户的交易、注销该用户账户，并有权要求其承担相应法律责任。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　二、用户的帐号，密码和安全性</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　用户一旦注册成功，成为本站的合法用户。用户将对用户名和密码安全负全部责任。此外，每个用户都要对以其用户名进行的所有活动和事件负全责。用户若发现任何非法使用用户帐号或存在安全漏洞的情况，请立即通告本站。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　三、云购夺宝原则</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1、释义</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　参与码：指云购夺宝网用户成功参与购物之后获得的随机分配编码。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　幸运参与码：指某件商品所有编码售出后，云购夺宝网根据规则计算出的一个编码，持有该编码的用户即可获得该商品。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2、云购夺宝网承诺遵循以下的原则运营网站，确保所有用户在云购夺宝网中享受同等的权利与义务。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　平等原则：用户和云购夺宝在交易过程中具有同等的法律地位。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　自由原则：用户享有自愿向云购夺宝参与购买商品的权利，任何人不得非法干预。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　公平原则：用户和云购夺宝行使权利、履行义务应当遵循公平原则。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　诚实信用原则：用户和云购夺宝行使权利、履行义务应当遵循诚实信用原则。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　履行义务原则：用户向云购夺宝参与商品分享购买时，用户和云购夺宝皆有有义务根据本服务协议的约定完成该等交易(法律或本协议禁止的交易除外)</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3、用户知悉，除本协议另有约定外，用户无论是否获得商品，参与购物的资金均用于帮助他人，不能退回;用户完全了解参与云购夺宝存在的风险，云购夺宝网无法保证用户参与购物一定会获得商品。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　四、用户的权利和义务</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1、用户有权拥有其在云购夺宝的用户名及密码，并用该用户名和密码登录云购夺宝参与商品购买。用户不得以任何形式转让或授权他人使用自己的云购夺宝用户名。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2、用户有权根据本协议的规定以及云购夺宝网站上发布的相关规则在云购夺宝上查询商品信息、发表使用体验、参与商品讨论、邀请关注好友、上传商品图片、参加云购夺宝的有关活动，以及享受云购夺宝提供的其它信息服务</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3、用户有义务在注册时提供自己的真实资料，并保证诸如电子邮件地址、联系电话、联系地址、邮政编码等内容的有效性及真实性，保证云购夺宝可以通过上述联系方式与用户本人进行联系。同时，用户也有义务在相关资料发生变更时及时更新有关注册资料。用户保证不以他人资料在云购夺宝进行注册和参与商品分享购买。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　4、用户应当保证在云购夺宝参与商品分享购买时遵守诚实信用原则，不扰乱网上交易的正常秩序。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　5、用户在成为云购夺宝的会员后，可按云购夺宝的福分规则享受福分获得。累积福分可用于福分商城中的相应福分商品兑换。福分规则连同与该规则相关的条款和条件，构成用户与云购夺宝之间的完整协议。接受本协议，即表明接受福分规则中的条款和条件。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　6、用户享有言论自由权利;并拥有适度修改、删除自己发表的文章的权利用户不得在云购夺宝发表包含以下内容的言论：</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1) 反对宪法所确定的基本原则，煽动、抗拒、破坏宪法和法律、行政法规实施的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2) 煽动颠覆国家政权，推翻社会主义制度，煽动、分裂国家，破坏国家统一的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3) 损害国家荣誉和利益的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　4) 煽动民族仇恨、民族歧视，破坏民族团结的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　5) 任何包含对种族、性别、宗教、地域内容等歧视的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　6) 捏造或者歪曲事实，散布谣言，扰乱社会秩序的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　7) 宣扬封建迷信、邪教、淫秽、色情、赌博、暴力、凶杀、恐怖、教唆犯罪的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　8) 公然侮辱他人或者捏造事实诽谤他人的，或者进行其他恶意攻击的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　9) 损害国家机关信誉的;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　10) 其他违反宪法和法律行政法规的。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　7、用户在发表使用体验、讨论图片等，除遵守本条款外，还应遵守该讨论区的相关规定。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　8、未经云购夺宝同意，禁止用户在网站发布任何形式的广告。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　五、云购夺宝的权利和义务</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1、云购夺宝有义务在现有技术上维护整个网上交易平台的正常运行，并努力提升和改进技术，使用户网上交易活动得以顺利进行;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2、对用户在注册和使用云购夺宝网上交易平台中所遇到的与交易或注册有关的问题及反映的情况，云购夺宝应及时作出回复;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3、对于用户在云购夺宝网站上作出下列行为的，云购夺宝有权作出删除相关信息、终止提供服务等处理，而无须征得用户的同意：</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1)云购夺宝有权对用户的注册信息及购买行为进行查阅，发现注册信息或购买行为中存在任何问题的，有权向用户发出询问及要求改正的通知或者作出删除等处理;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2)用户违反本协议规定或有违反法律法规和地方规章的行为的，云购夺宝有权停止传输并删除其信息，禁止用户发言，注销用户账户并按照相关法律规定向相关主管部门进行披露。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3)对于用户在云购夺宝进行的下列行为，云购夺宝有权对用户采取删除其信息、禁止用户发言、注销用户账户等限制性措施：包括发布或以电子邮件或以其他方式传送存在恶意、虚假和侵犯他人人身财产权利内容的信息，进行与分享购物无关或不是以分享购物为目的的活动，恶意注册、签到、评论等方式试图扰乱正常购物秩序，将有关干扰、破坏或限制任何计算机软件、硬件或通讯设备功能的软件病毒或其他计算机代码、档案和程序之资料，加以上载、发布、发送电子邮件或以其他方式传送，干扰或破坏云购夺宝网站和服务或与云购夺宝网站和服务相连的服务器和网络，或发布其他违反公共利益或可能严重损害云购夺宝和其它用户合法利益的信息。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　4、用户在此免费授予云购夺宝永久性的独家使用权(并有权对该权利进行再授权)，使云购夺宝有权在全球范围内(全部或部分地)使用、复制、修订、改写、发布、翻译和展示用户公示于云购夺宝网站的各类信息，或制作其派生作品，和或以现在已知或日后开发的任何形式、媒体或技术，将上述信息纳入其它作品内。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　5、对于云购夺宝网络平台已上架商品，云购夺宝有权根据市场变动修改商品价格，而无需提前通知客户。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　6、云购夺宝分享购物模式，秉着双方自愿原则，分享购物存在风险，云购夺宝不对抽取的“幸运编号”结果承担责任，望所有用户谨慎参与。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　7、90天未达到“总需参与人次”的商品，用户可通过客服申请退款，所退款项将在3个工作日内，退还至购物账户中。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　六、配送及费用</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　云购夺宝将会把产品送到您所指定的送货地址。全国免费配送(港澳台地区除外)。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　请清楚准确地填写您的真实姓名、送货地址及联系方式。因如下情况造成配送延迟或无法配送等，本站将不承担责任：</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1、客户提供错误信息和不详细的地址;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2、货物送达无人签收，由此造成的重复配送所产生的费用及相关的后果。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3、不可抗力，例如：自然灾害、交通戒严、突发战争等。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　七、商品缺货规则</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　由于市场变化及各种以合理商业努力难以控制的因素的影响，云购夺宝网无法承诺用户所获得的商品都会有货;用户获得的商品或服务如果发生缺货，协议双方均无权取消该交易，云购夺宝网将通过有效方式通知用户进行换货，用户可选择换购本商城同等价位的商品(一件或多件)，或选择补差价换购高价位商品。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　云购夺宝网可对即将上市的商品或服务进行预售登记，云购夺宝网会在商品或者服务正式上市之后尽最大努力在最快时间内给商品获得者安排发货，预售登记并不做交易处理，不构成要约。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　八、责任限制</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1、用户理解并同意，在使用云购夺宝网服务的过程中，可能会遇到不可抗力等风险因素使云购夺宝网服务发生中断。不可抗力是指不能预见、不能克服并不能避免且对一方或双方造成重大影响的客观事件，包括但不限于自然灾害如洪水、地震、瘟疫流行和风暴等以及社会事件如战争、动乱、政府行为等。出现上述情况时，云购夺宝网将努力在第一时间与相关单位配合，及时进行修复，但是由此给用户造成的损失，云购夺宝网将在法律允许的范围内免责。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2、用户理解并同意，云购夺宝网不能随时预见和防范法律、技术以及其他不可控的风险，对以下情形之一导致的服务中断或受阻，云购夺宝网不承担责任：</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　(1)大规模病毒、木马或其他恶意程序、黑客攻击的破坏;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　(2)用户或云购夺宝网的电脑软件、系统、硬件和通信线路出现故障;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　(3)用户操作不当;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　(4)用户通过非云购夺宝网授权的方式使用服务;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　(5)政府管制等原因可能导致的服务中断、数据丢失以及其他的损失和风险。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　(6)其他云购夺宝网无法控制或合理预见的情形。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3、在法律法规所允许的限度内，因使用云购夺宝服务而引起的任何损害或经济损失，云购夺宝承担的全部责任均不超过用户所购买的与该索赔有关的商品价格。这些责任限制条款将在法律所允许的最大限度内适用，并在用户资格被撤销或终止后仍继续有效。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　九、网络服务内容的所有权</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　本站定义的网络服务内容包括：文字、软件、声音、图片、录象、图表、广告中的全部内容;电子邮件的全部内容;本站为用户提供的其他信息。所有这些内容受版权、商标、标签和其它财产所有权法律的保护。所以，用户只能在本站和广告商授权下才能使用这些内容，而不能擅自复制、再造这些内容、或创造与内容有关的派生产品。本站所有的文章版权归原文作者和本站共同所有，任何人需要转载本站的文章，必须征得原文作者或本站授权。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　十、用户隐私制度</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　我们不会向任何第三方提供，出售，出租，分享和交易用户的个人信息。当在以下情况下，用户的个人信息将部分或全部被善意披露：</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1、经用户同意，向第三方披露;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2、如用户是合资格的知识产权投诉人并已提起投诉，应被投诉人要求，向被投诉人披露，以便双方处理可能的权利纠纷;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3、根据法律的有关规定，或者行政或司法机构的要求，向第三方或者行政、司法机构披露;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　4、如果用户出现违反中国有关法律或者网站政策的情况，需要向第三方披露;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　5、为提供你所要求的产品和服务，而必须和第三方分享用户的个人信息;</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　6、其它本站根据法律或者网站政策认为合适的披露。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　十一、法律管辖和适用</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　1、本协议的订立、执行和解释及争议的解决均应适用中国法律。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　2、如发生本站服务条款与中国法律相抵触时，则这些条款将完全按法律规定重新解释，而其它合法条款则依旧保持对用户产生法律效力和影响。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　3、本协议的规定是可分割的，如本协议任何规定被裁定为无效或不可执行，该规定可被删除而其余条款应予以执行。</span></p><p><span style=\"font-family: 微软雅黑, &#39;Microsoft YaHei&#39;;\">　　4、如双方就本协议内容或其执行发生任何争议，双方应尽力友好协商解决;协商不成时，任何一方均可向本站所在地的人民法院提起诉讼。</span></p>', '1524', '0', '1514880240');
INSERT INTO `go_article` VALUES ('4', '3', 'admin', '保障体系', '', '', 'a:0:{}', '', '', '<p>100%正品保证</p><p>云购夺宝商城精心挑选优质服务品牌商家，保障全场商品100%品牌正品。</p><p>100%公平公正</p><p>整个过程是完全透明，您可以随时查看每件商品参与人数，参与次数，参与名单及中奖信息等记录。</p><p>全国免费快递</p><p>云购夺宝商城承诺全场所有商品全国免费快递。（港澳台地区除外）</p><p><br/></p><p><br/></p><p><br/></p>', '1452', '0', '1514966640');
INSERT INTO `go_article` VALUES ('5', '3', 'admin', '正品保障', '', '', 'a:0:{}', '', '', '<p><br/></p><p>云购夺宝商城严格控制供应渠道，全部商品均从品牌官方以及品牌经销商直接采购供货，并取得品牌官方网络销售授权书，如果您认为夺宝的商品是假货，并能提供国家相关质检机构的证明文件，经确认后，在返还商品金额的同时并提供假一赔十服务保障。为了保障您的利益，对夺宝的商品，做如下说明：</p><p>1、云购夺宝商城对所有商品均保证正品行货，正规渠道发货，所有商品都可以享受生产厂家的全国联保服务，按照国家三包政策，针对所售商品履行保修、换货和退货的义务。</p><p>2、出现国家三包所规定的功能性故障时，经由生产厂家指定或特约售后服务中心检测确认故障属实，您可以选择换货或者维修；超过15日且在保修期内，您只能在保修期内享受免费维修服务。为了不耽误您使用，缩短故障商品的维修时间，我们建议您直接联系生产厂家售后服务中心进行处理。您也可以直接在商品的保修卡中查找该商品对应的全国各地生产厂家售后服务中心联系处理。</p><p>3、云购夺宝商城真诚提醒广大幸运者在您收到商品的时候，请尽量亲自签收并当面拆箱验货，如果有问题(运输途中的损坏)请不要签收!与快递员交涉，拒签，退回!</p><p>4、在收到商品后发现有质量问题，请您不要私自处理，妥善保留好原包装，第一时间联系云购夺宝商城客服人员，由云购夺宝商城同发货商城协商在48小时内解决。如有破损或丢失，我们将无法为您办理退货。</p><p>如对协商处理结果存在异议，请您自行到当地生产厂家售后服务中心进行检测，并开据正规检测报告（对于有些生产厂家售后服务中心无法提供检测报告的，需提供维修检验单据），如果检测报告确认属于质量问题，然后将检测报告、问题商品及完整包装附件，一并返还发货商城办理换货手续，产生的相关费用由云购夺宝商城追究相关责任方承担。</p><p>云购夺宝商城上的电子产品及配件因为生成工艺或仓储物流原因，可能会存在收到或使用过程中出现故障的几率，云购夺宝商城不能保证所有的商品都没有故障，但我们保证所售商品都是全新正品行货，能够提供正规的售后保障。我们保证商品的正规进货渠道和质量，如果您对收到的商品质量表示怀疑，请提供生产厂家或官方出具的书面鉴定，我们会按照国家法律规定予以处理。但对于任何欺诈性行为，云购夺宝商城将保留依法追究法律责任的权利。本规则最终解释权由云购夺宝商城所有。<br/></p><p><br/></p>', '1452', '0', '1514880300');
INSERT INTO `go_article` VALUES ('7', '4', 'admin', '商品配送', '', '', 'a:0:{}', '', '', '<p>	</p><p><br/></p><p>欢迎使用云购夺宝商城网，请注意字符长度限制哦~!</p><p><br/></p>', '586', '0', '1514880300');
INSERT INTO `go_article` VALUES ('8', '4', 'admin', '配送费用', '', '', 'a:0:{}', '', '', '<p>	</p><p><br/></p><p>欢迎使用云购夺宝商城网，请注意字符长度限制哦~!</p><p><br/></p>', '785', '0', '1514880300');
INSERT INTO `go_article` VALUES ('10', '4', 'admin', '长时间未收到商品', '', '', 'a:0:{}', '', '', '<p style=\"margin: 0px; padding: 0px; text-align: left; color: rgb(128, 128, 128); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: 微软雅黑; font-size: 12px; font-style: normal; font-weight: normal; word-spacing: 0px; list-style-type: none; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px;\"><span style=\"color: rgb(0, 0, 0); font-size: 18px;\">长时间未收到商品可能出现的问题：</span></p><p style=\"margin: 0px; padding: 0px; text-align: left; color: rgb(128, 128, 128); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: 微软雅黑; font-size: 12px; font-style: normal; font-weight: normal; word-spacing: 0px; list-style-type: none; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px;\"><span style=\"color: rgb(0, 0, 0); font-size: 18px;\">1、请您确保您的收货地址、电话、等各项信息的准确性，以便商品及时、准确地发出。</span></p><p style=\"margin: 0px; padding: 0px; text-align: left; color: rgb(128, 128, 128); text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: 微软雅黑; font-size: 12px; font-style: normal; font-weight: normal; word-spacing: 0px; list-style-type: none; white-space: normal; orphans: 2; widows: 2; background-color: rgb(255, 255, 255); font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px;\"><span style=\"color: rgb(0, 0, 0); font-size: 18px;\">2、当您的商品送达目的地之后，如快递人员在快件保管期（一般3-7天）未能联系到您，快件将退回，我们会联系您进行二次配送，由此产生的费用将由您自行承担。</span></p><p><br style=\"text-align: left;\"/></p>', '536', '0', '1514880360');
INSERT INTO `go_article` VALUES ('12', '3', 'admin', '隐私声明', '', '', 'a:0:{}', '', '', '<p>	</p><p><br/></p><p><br/></p><p><br/></p><p><br/></p><h1 style=\" text-decoration: underline;\">隐私声明</h1><p><br/>友邦保险控股有限公司及/或其附属公司（以下分别及统称为“友邦保险”）其中一项最重要的资产，就是客户对友邦保险能适当处理其信息的信赖和信任。客户及\n潜在客户期望我们准确维护其信息，保护信息免遭篡改和错误使用，失窃以及无未经客户授权泄露信息之虞。我们遵行适用的隐私相关法律和规章制度，以期为客户\n及潜在客户的个人资料提供安全保障，并确保员工遵守严格的安全及保密标准。</p><p><br/>本声明旨在您告知您我公司收集您个人资料的原因、资料可能的用途、可能获得您个人资料的第三方，有关您查阅、检查及修订您个人资料的方法，以及我们直接销\n售及使用Cookies（网络跟踪器）的政策。使用本网站即表示您接受本隐私声明中的惯例做法及政策。若您反对本声明中的任何惯例做法及政策，请不要使用\n本网站将个人资料提交给友邦保险。</p><p><br/>本网站仅提供一般资料。虽然我们已尽合理努力，确保本网站的资料准确，友邦保险概不保证资料绝对准确，亦概不为资料不准确或因任何错漏所产生的任何损失或损害而承担任何责任。如未得到友邦保险事前准许，不得复制（作为个人用途例外）或转发本网站所载的任何资料。</p><p><br/>友邦保险承认其负有有关收集、持有、处理或使用私人数据的责任。您提供个人资料，纯属自愿性质。您可选择不向我们提供所需的个人资料，但这样做会影响到我\n们为您提供服务的能力。友邦保险不会通过本网站收集任何可识别您身份的资料，除非直至您购买我们的产品或服务，登记成为客户或基于申请职位而提供个人资料\n起为始。</p><p><br/>若您处于限制我们分发资料或使用有关社交媒体平台的司法管辖区内，则不应使用本网站及我们的社交媒体平台。若此规定适用于您，我们建议您自行了解及遵从有关限制，友邦保险概不因此而承担任何责任。</p><h1><br/>收集资料的方法</h1><p><br/>我们将会收集及储存您在本网站输入的资料，或通过其他渠道向我们提供的资料。我们亦会从附属公司、商业伙伴及其他独立第三方资料来源，获取与您有关并合法收集的个人或非个人资料。在您到访本网站时，我们亦收集与您所用电脑或其他装置有关的某些资料。</p><p><br/>若您在本网站，我们所提供的应用程序或另行通过社交媒体供应商使用任何社交媒体功能或平台，我们可能通过有关社交媒体供应商，按照其有关政策查阅及收集与\n您有关的资料。在使用社交媒体功能时，我们可能会查阅及收集您于您的社交媒体个人账户选择提供并列入在内的资料，有关资料包括（但不限于）您的姓名、性\n别、出生日期、电邮地址、地址、地点等。您在有关社交媒体供应商所作的隐私设定，可限制或阻止我们对有关资料的查阅。</p><h1><br/>收集您个人资料的原因及可能用途</h1><p><br/>收集个人资料可作以下用途：</p><ul class=\" list-paddingleft-2\"><li><p>处理、实施、执行和实行在本网站上所提供的表格中或您可能不时交予我们的任何其他文件项下的要求或交易；</p></li><li><p>设计全新或加强目前我们所提供的产品及服务；</p></li><li><p>与您保持联繫，包括向您寄发有关您在我们公司任何账户或本隐私声明日后变动的通讯；</p></li><li><p>供友邦保险、金融服务业或我们的相关监管机构的统计或精算研究之用；</p></li><li><p>供我们作资料匹配，内部业务及管理之用；</p></li><li><p>协助执行法例、警方或其他政府或监管机构调查，以及遵守适用法律及规例所施行的规定，或其他向政府或监管机构承诺之义务；</p></li><li><p>将我们网站的外观个人化，提供相关产品的建议，以及在本网站或通过其他渠道进行目标广告活动；</p></li><li><p>在收集之时所通知的其他用途；及</p></li><li><p>与上述任何项目直接有关的其他用途。</p></li></ul><p><br/>若您提供个人资料予我们，即表示您接受，友邦保险将可因所需期限留存资料以履行有关用途，而就该等用途而言，有关资料乃在遵守适用相关法律及规定的情况下\n收集。友邦保险采用合理的保障措施，包括限制亲身查阅友邦保险系统内的数据及在转移敏感数据时进行加密处理，以防止未经许可或意外的查阅、处理、删除、丢\n失或使用情况。若不再需要用作上述任何用途，将会采取合理步骤删除或销毁有关资料。</p><p><br/>有关我们使用您个人资料作宣传或市场推广用途的政策，请参阅「使用个人资料作直接促销用途」一节。</p><h1><br/>谁会取得您的个人资料？</h1><p><br/>个人资料将保密处理，仅在法律许可且就符合收集个人资料用途或直接相关用途而披露是必须时，方可向以下各方提供相关个人资料（有关我们分发您个人资料作宣传或市场推广用途的政策，请参阅「使用个人资料作直接促销用途」一节。）：</p><ul class=\" list-paddingleft-2\"><li><p>获授权担任友邦保险代理且与分销友邦保险所提供之产品及服务有关的任何人士；</p></li><li><p>就友邦保险营运以及友邦保险向您提供服务相关而提供管理、数据处理、电讯、电脑、付款、收债或证券结算、技术外判、电话中心服务、邮寄及印刷服务的任何代理、承包商或第三方服务供应商（无论在友邦保险内或外）；</p></li><li><p>与提供或促销保险服务有关的友邦保险任何成员公司；</p></li><li><p>任何代理、承包商或第三方服务供应商（无论在友邦保险内或外），包括协助提供服务的公司，例如再保险公司、投资管理公司、索赔调查公司、业界协会或联盟；</p></li><li><p>协助收集您资料或与您联系的其他公司，例如研究调查公司及信贷评级机构，藉以加强我们向您所提供的服务；及</p></li><li><p>政府或监管机构或友邦保险公司：(a)根据在该司法管辖区适用于该友邦保险公司的法律及监管义务而必须对其披露的任何人士；或(b)依据该友邦保险公司与相关政府、监管机构或其他人士协议必须对其披露的任何人士。</p></li></ul><p><br/>就我们因在提供保险服务而收集的个人资料，该等个人资料将只会提供予上述人士作提供相关保险服务的用途。</p><p><br/>我们可不时购买业务或出售我们一项或多项业务（或其部分），而在法律许可的情况下，您的个人资料可作为该买卖或建议买卖的一部分予以转让或披露。若我们购买一项业务，就该业务所获得的个人资料将在其可行及允许的情况下根据本隐私声明处理。</p><p><br/><strong>若法律法规许可，可将您的个人资料提供予上述任何一方，有关各方可位于中国大陆境内或境外。</strong>您的资料，将可转移往中国\n大陆或任何友邦保险公司所在的司法管辖区，或第三方承包商所在的司法管辖区或第三方承包商于该处为我们提供服务的司法管辖区，并在中国大陆或有关司法管辖\n区储存及处理。若您向我们提供个人资料，或使用我们的服务或本网站或应用程式，即表示您同意将有关资料从您的司法管辖区转移至我们在其之外的设施，或如上\n文所载转移至我们与其分享有关资料的第三方。</p><h1><br/>查阅个人资料的权利</h1><p><br/>您有权：</p><ul class=\" list-paddingleft-2\"><li><p>核实友邦保险是否持有您的个人资料，并查阅任何该等资料；</p></li><li><p>要求友邦保险更正任何有关您的错误个人资料；及</p></li><li><p>就友邦保险有关个人资料的政策及惯例作出查询。</p></li></ul><p><br/>如欲查阅、更正您个人资料或有相关的其他要求，可致函至以下地址：</p><p>信息安全负责人<br/>上海市黄浦区中山东一路17号<br/>友邦保险中国区合规部</p><p><br/>友邦保险有权就因处理任何查阅个人资料的要求收取需要和直接相关的费用。</p><h1><br/>使用个人资料作直接销售用途</h1><p><br/>除上述用途外，在法律许可的情况下，友邦保险可使用您的姓名和联络资料作宣传或市场推广用途，包括向您寄发宣传资料及就以下产品、服务、建议、目的作直接\n销售及后续的保险服务然而，就友邦保险因在提供保险服务而收集的个人资料，该等个人资料将只会用作宣传或推广直接与保险相关的产品或服务。</p><p><br/>鉴于直接促销的用途，在法律许可的情况下，除因友邦保险在提供保险服务所收集的个人资料外，我们或会将您的个人资料提供予任何上述描述的促销标的类别、电\n话中心、市场推广或研究服务的提供商（无论在友邦保险内或外），从而他们可就其所提供的产品及服务向您寄发宣传资料及进行直接促销，有关资料可透过邮寄、\n电邮或其他方式送达予您。在法律许可的情况下，我们或会将您的个人资料提供予任何以上描述的促销标的类别的提供商（无论在友邦保险内或外）而得益。</p><p><br/>就本节用途使用或向本部分受让方提供您的个人资料前，我们可能受法律所规定要取得您的书面同意，且在该等情况下，仅会在取得有关书面同意后方就任何宣传或市场推广用途使用或提供您的个人资料。</p><p><br/>友邦保险会使用及提供作上述直接促销用途的个人资料为您的姓名和相关联络资料；然而，我们可管有更多的个人资料。</p><p><br/>如要求您同意，而您给予该等同意，您可于其后撤回对友邦保险使用并向第三者提供您的个人资料作直接促销用途的同意；此后，友邦保险须停止使用或提供该等资料作直接促销之用。</p><p><br/>如您已给予同意但又欲将其撤回，请以书面或电邮方式通知我们，书面通知可邮寄至「查阅个人资料的权利」一节所载地址，而电邮可发送至privacy.compliance@aia.com。任何有关请求应清楚列明该要求相关的个人资料详情。</p><h1><br/>使用Cookies</h1><p><br/>Cookies乃网络伺服器放置在您的电脑或其他装置的独一无二标识符，其载有资料，可在其后由向您发Cookies的伺服器解读。友邦保险亦可在其维持\n的网站使用Cookies。所收集的资料（包括（但不限于）您的IP位址（及网域名称）、浏览器软件、浏览器的类别及配置，语言设定、地理位置、作业系\n统、转介网站、所浏览网页及内容及到访期间）将用作编製访客怎样到达及浏览我们网站的总体统计数字，协助我们瞭解如何改善您到访我们网站的体验。有关资料\n将会以不具名方式收集，并不能识别您的身份，除非您以会员身份登入，则作别论。我们只会使用有关资料作增进及优化网站。Cookies亦让我们的网站就您\n及您的喜好留下记录，让我们可按您的需要，为您度身设定网站。广告Cookies亦可让我们的网站提供与您尽可能有关的广告，如为您甄选以兴趣为主的广\n告，或阻止不断向您展现同一广告等。</p><p><br/>大部份网页浏览器在最初已设定为可接受Cookies。若您不愿接收Cookies，可在您的浏览器设定中关闭有关功能。然而，如关闭功能，您将不能尽享我们网站的优点，而若干功能可能不可以正常运作。</p><h1><br/>外部链接</h1><p><br/>若本网站任何部分载有连接其他网站的链接，有关网站可能并非根据本隐私声明运作隐私，藉以瞭解其收集、使用、转移及披露个人资料的政策。</p><h1><br/>本隐私声明的修订</h1><p><br/>友邦保险保留权利可随时且在无须通知的情况下仅凭知会您有关修改、更新或修订，而增添、修改、更新或修订本隐私声明。倘我们决定修改我们的个人资料政策，\n我们将于我们的网站知会您有关修改，从而让您能得悉我们所收集的资料、我们如何使用该资料及在何种情况下会披露该资料。任何有关修改、更新或修订将在刊登\n后即时生效。</p><h1><br/>其他资料</h1><p><br/>如您对本隐私声明的任何部分有任何疑问或如欲知悉有关友邦保险的资料保密惯例的更多资料，请随时通过上述联络途径与我们联络。</p><p>&nbsp;</p><h1 style=\" text-decoration: underline;\">PRIVACY STATEMENT</h1><p><br/>Among the most important assets of AIA Group Limited and/or its\nsubsidiaries (individually and collectively referred to herein as “AIA”) is the trust and confidence placed to properly handle information.\nCustomers and potential customers expect us to maintain their\ninformation accurately, protected against manipulation and errors,\nsecure from theft and free from unwarranted disclosure. We protect the\ndata security of our customers and potential customers by complying with the Personal Data (Privacy) Ordinance, and all relevant local laws, and ensure compliance by our staff with strict standards of security and\nconfidentiality.</p><p><br/>This statement provides you with notice as to why your personal data is\ncollected, how it is intended to be used, to whom your personal data may be transferred to, how to access, review and amend your personal data,\nand our policies on direct marketing and the use of cookies. By using\nthis website, you are accepting the practices and policies in this\nprivacy statement. If you object to any practices and policies in this\nstatement, please do not use this website to submit your personal\ninformation to AIA.</p><p><br/>This website is for general information purpose only. While we use\nreasonable efforts to ensure the accuracy of the information on this\nwebsite, AIA does not warrant its absolute accuracy or accept any\nliability for any loss or damage resulting from any inaccuracy or\nomission. Without prior permission from AIA, no information contained on this website may be copied, except for personal use, or redistributed.</p><p><br/>AIA recognises its responsibilities in relation to the collection,\nholding, processing or use of personal data. The provision of your\npersonal data is voluntary. You may choose not to provide us with the\nrequested data, but failure to do so may inhibit our ability to do\nbusiness with or provide services to you. AIA will not collect any\ninformation that identifies you personally through this website unless\nand until you buy our products or services, register as a member, or\nsubmit personal information for job application purposes.</p><p><br/>This website, and our social media platforms are not intended for\npersons in jurisdictions that restrict the distribution of information\nby us or use of such social media platforms. If this is applicable to\nyou, we would advise you to inform yourself about and observe the\nrelevant restrictions, and AIA does not accept liability in this\nrespect.</p><h1><br/>How we collect data.</h1><p><br/>We will collect and store any information you enter on our website, or\nprovide to us through any other channel. We may also obtain lawfully\ncollected personal or non-personal information about you from affiliated entities, business partners and other independent third parties\nsources. We may also collect some information about your computer or\nother devices used when you visit this website.</p><p><br/>If you make use of any social media features or platforms, either on our website, an application we provide, or otherwise through a social media provider, we may access and collect information about you via that\nsocial media provider in accordance with their policies. When using a\nsocial media feature, we may access and collect information you have\nchosen to make available and to include in your social media profile or\naccount, including but not limited to your name, gender, birthday, email address, address, location etc. Our access to this information may be\nlimited or blocked based on your privacy settings with the relevant\nsocial media provider.</p><h1><br/>Why we collect your personal data and how it may be used?</h1><p><br/>Personal data is collected for the following purposes:</p><ul class=\" list-paddingleft-2\"><li><p>to process, administer, implement and effect the requests or\ntransactions contemplated by the forms available on our website or any\nother documents you may submit to us from time to time;</p></li><li><p>to design new or enhance existing products and services provided by us;</p></li><li><p>to communicate with you including to send you administrative\ncommunications about any account you may have with us or about future\nchanges to this privacy statement;</p></li><li><p>for statistical or actuarial research undertaken by AIA, the financial services industry or our respective regulators;</p></li><li><p>for data matching, internal business and administrative purposes;</p></li><li><p>to assist in law enforcement purposes, investigations by police or\nother government or regulatory authorities and to meet requirements\nimposed by applicable laws and regulations or other obligations\ncommitted to government or regulatory authorities;</p></li><li><p>to personalise the appearance of our websites, provide\nrecommendations of relevant products and provide targeted advertising on our website or through other channels;</p></li><li><p>other purposes as notified at the time of collection;and</p></li><li><p>other purposes directly relating to any of the above.</p></li></ul><p><br/>By providing your personal information to us, you accept that AIA may\nretain your information for as long as necessary, to fulfill the\npurpose(s) for which it is collected in compliance with applicable laws\nand regulations. AIA applies reasonable security measures to prevent\nunauthorised or accidental access, processing, erasure, loss or use\nincluding limiting physical access to data within AIA’s systems and\nencryption of sensitive data when transferring such data. Reasonable\nsteps will be taken to delete or destroy the information when it is no\nlonger necessary for any of the purpose above.</p><p><br/>For our policy on use of your personal data for promotional or marketing purposes, please see the section entitled “Use of Personal Data for\nDirect Marketing Purposes”.</p><h1><br/>Who may be provided with your personal data?</h1><p><br/>Personal data will be kept confidential but may, where permitted by law\nand where such disclosure is necessary to satisfy the purpose or a\ndirectly related purpose for which the personal data was collected,\nprovide such personal data to the following parties (for our policy on\nsharing of your personal data for promotional and marketing purposes,\nplease see the section entitled “Use of Personal Data for Direct\nMarketing Purposes”):</p><ul class=\" list-paddingleft-2\"><li><p>any person authorised to act as an agent of AIA in relation to the distribution of products and services offered by AIA;</p></li><li><p>any agent, contractor or third party service provider (within or\noutside AIA) who provides administration, data processing,\ntelecommunications, computer, payment, debt collection or securities\nclearing, technology outsourcing, call centre services, mailing and\nprinting services in connection with the operation of AIA’s business and AIA’s provision of services to you;</p></li><li><p>any member company of AIA in relation to the provision or marketing of insurance services;</p></li><li><p>any agent, contractor or third party service provider (within or\noutside AIA) including companies that help deliver our services, such as reinsurance companies, investment management companies, claims\ninvestigation companies, industry associations or federations;</p></li><li><p>other companies that help gather your information or communicate\nwith you, such as research companies and ratings agencies, in order to\nenhance the services we provide to you;and</p></li><li><p>government or regulatory bodies or any person to whom an AIA company must disclose data: (a) under a legal and/or regulatory obligation in\nthat jurisdiction applicable to that particular AIA company; or (b)\npursuant to an agreement between the AIA company and the relevant\ngovernment, regulatory body or other person.</p></li></ul><p><br/>In relation to any personal data collected by us whilst providing any\nservices in respect of our insurance plans, such personal data would\nonly be transferred to the above parties for the purpose of providing\nany insurance related services.</p><p><br/>From time to time, we may purchase a business or sell one or more of our businesses (or portions thereof) and where permitted by law your\npersonal data may be transferred or disclosed as a part of the purchase\nor sale or a proposed purchase or sale. In the event that we purchase a\nbusiness, the personal data received with that business would be treated in accordance with this privacy statement, if it is practicable and\npermissible to do so.</p><p><br/><strong>Where permitted by law, your personal data may be provided to\nany of the above parties who may be located in The mainland of China or\noutside of The mainland of China.</strong>Your information may be\ntransferred to, stored, and processed in The mainland of China or any\nother jurisdictions where any AIA company is located, or jurisdictions\nwhere a third party contractor is located or from which the third party\ncontractor provides us services. By providing us with your personal\ninformation or using our services or our website or applications, you\nconsent to the transfer of such information outside your jurisdiction to our facilities or to those third parties with whom we share it as\ndescribed above.</p><h1><br/>Access Rights to Personal Data</h1><p><br/>You have the right to:</p><ul class=\" list-paddingleft-2\"><li><p>verify whether AIA holds any personal data about you and to access any such data;</p></li><li><p>require AIA to correct any personal data relating to you which is inaccurate;and</p></li><li><p>enquire about AIA’s policies and practices in relation to personal data.</p></li></ul><p><br/>Requests for access, correction or other queries relating to your personal data should be addressed to:</p><p>The Data Protection Officer</p><p>AIA CHO Compliance<br/>No.17 Zhongshan Dong Yi Road<br/>Shanghai<br/>China</p><p>AIA has the right to charge costs which are directly related to and\nnecessary for the processing of any personal data access request.</p><h1><br/>Use of Personal Data for Direct Marketing purposes</h1><p><br/>In addition to the purposes set out above, where permitted by law, AIA\nmay use your name and contact details for promotional or marketing\npurposes including sending you promotional materials and conducting\ndirect marketing in relation to the insurance products, services, advice and subjects. However, in relation to any personal data collected by\nAIA whilst providing any services in respect of our insurance plans,\nsuch personal data would only be used for promoting or marketing any\nproducts or services that are directly related to our insurance plans.</p><p><br/>For the purposes of direct marketing, we may, where permitted by law,\nprovide your personal information (with the exception of any personal\ndata collected by AIA whilst providing any services in respect of our\nmandatory provident fund master trust schemes) to providers (whether\nwithin or outside of AIA) of any of the Classes of Marketing Subjects\ndescribed above and call centre, marketing or research services so that\nthey can send you promotional materials and conduct direct marketing in\nrelation to the products and services they offer (these materials may be sent to you by postal mail, email or other means). Where permitted by\nlaw, we may provide your personal data to providers (whether within or\noutside of AIA) of any of the Classes of Marketing Subjects for gain.</p><p><br/>Before using or providing your personal data for the purposes and to the transferees set out in this section, we may be required by law to\nobtain your written consent, and in such cases, only after having\nobtained such written consent, may we use and provide your personal data for any promotional or marketing purpose.</p><p><br/>The types of personal data that AIA would use and provide for direct\nmarketing purposes as described above are your name and relevant contact details, although we may possess additional personal data.</p><p><br/>If your consent is required, and you provide such consent, you may\nthereafter withdraw your consent to the use and provision to a third\nparty by AIA of your personal data for direct marketing purposes and\nthereafter AIA shall cease to use or provide such data for direct\nmarketing purposes.</p><p><br/>If you have provided consent and wish to withdraw it, please inform us\nby writing to the address in the section on “Access Rights to Personal\nData” or sending us an email to privacy.compliance@aia.com. Any such\nrequest should clearly state details of the personal data in respect of\nwhich the request is being made.</p><h1><br/>Use of Cookies</h1><p><br/>Cookies are unique identifiers placed on your computer or other device\nby a web server, which contains information that can later be read by\nthe server that issued the cookie to you. AIA may use cookies on various websites we maintain. The information collected (including but not\nlimited to: your IP addresses (and domain names), browser software,\ntypes and configurations of your browser, language settings,\ngeo-locations, operating systems, referring website, pages and content\nviewed, and durations of visit) will be used for compiling aggregate\nstatistics on how our visitors reach and browse our websites to help us\nunderstand how we can improve your experience on it. Such information is collected anonymously and you cannot be identified unless you have\nlogged on as a member. We use such data only for website enhancement and optimisation purposes. The cookies also enable our website to remember\nyou and your preferences, and tailor the website for your needs.\nAdvertising cookies will allow us to provide advertisements on our\nwebsites that are as relevant to you as possible, e.g. by selecting\ninterest-based advertisements for you, or preventing the same advisement from constantly reappearing to you.</p><p><br/>Most web browsers are initially set up to accept cookies. If you do not\nwant to receive cookies, you can disable this function in your browser\nsettings. However, by doing so you may not be able to fully enjoy the\nbenefits of our websites and certain features may not work properly.</p><h1><br/>External links</h1><p><br/>If any part of this website contains links to other websites, those\nsites may not operate under this privacy statement. You are advised to\ncheck the privacy statements on those websites to understand their\npolicies on the collection, usage, transferal and disclosure of personal data.</p><h1><br/>Amendments to this Privacy Statement</h1><p><br/>AIA reserves the right, at any time and without notice, to add to,\nchange, update or modify this privacy statement, simply by notifying you of such change, update or modification. If we decide to change our\npersonal data policy, those changes will be notified on our website so\nthat you are always aware of what information we collect, how we use the information and under what circumstances the information is disclosed.\nAny such change, update or modification will be effective immediately\nupon posting.</p><h1><br/>Additional Information</h1><p><br/>Should you have any questions on any part of this privacy statement or\nwould like additional information regarding AIA’s data privacy practices please do not hesitate to contact us by the contact details above.</p><p><br/></p>', '71', '1', '1514877360');
INSERT INTO `go_article` VALUES ('13', '16', 'admin', '基金的建立', '', '', 'a:0:{}', '', '', '<p>	</p><p><br/></p><p><br/></p><p><br/></p><p>&nbsp;— 惊喜无线创始人发起成立的以公益事业为主要方向的爱心基金。基金本着“我为人人，人人为我”的社会责任，向需要帮助的困难人们提供爱心捐助。</p>', '66', '1', '1513698780');
INSERT INTO `go_article` VALUES ('14', '16', 'admin', '基金的筹备办法', '', '', 'a:0:{}', '', '', '<p>	</p><p><br/></p><p><br/></p><p><br/></p><p>&nbsp;— 惊喜无线进行分享购物的朋友，您的每次参与都将是为我们的公益事业做出一份贡献。当您每参与1人次，将由1元出资为基金筹款0.01元，所筹款项将全部用于基金。<br/></p>', '345', '1', '1513698840');
INSERT INTO `go_article` VALUES ('15', '16', 'admin', '基金的去向', '', '', 'a:0:{}', '基金的去向', '', '<p><br/></p><p><br/></p><p><br/>一、购买基金是1块钱购买创始人发起成立的以公益事业为主要方向的爱心基金。购买基金本着“我为人人，人人为我”的社会责任，向需要帮助的困难人们提供爱心捐助。</p><p><br/></p><p><br/>二、每位在1块钱购买进行分享购物的朋友，您的每次参与都将是为我们的公益事业做出一份贡献。当您每参与1人次购买，将由1块钱购买出资为购买基金筹款0.01块钱，所筹款项将全部用于购买基金。</p><p><br/></p><p><br/>三、购买基金将会以第1种途径或第2种途径进行使用：</p><p>1、1块钱购买全体员工将组织向身边的公益事业进行捐赠与关怀活动。活动内容包括：资金、所需用品以及探望与协助等，每次捐赠与关怀活动结束后购买基金将公布活动详情以及基金详细使用报告。</p><p>2、购买基金通过腾讯公益或壹基金等公益组织进行爱心捐赠。</p><p><br/></p><p><br/>四、包括购买基金的捐赠活动，我们不定期开展内部全体员工对身边更多公益事业或实时公益事业进行爱心捐赠的社会活动。</p><p>&nbsp;&nbsp;&nbsp; 我们还将不定期邀请幸运者参与并见证我们的基金社会活动，共同为我们的社会责任付出一份爱心与力量。当活动启动前我们会将活动进行公告，您可自愿或自行组织参与，组成购买网大家庭，共同开启活动之行。凡参与社会活动的幸运者均能获得购买网为您精心准备的公益爱心礼品一份。</p><p><br/></p><p><br/></p><p><br/></p>', '54', '1', '1514908560');
INSERT INTO `go_article` VALUES ('17', '142', 'admin', '网站公告标题01', '', '', 'a:0:{}', '', '', '<p>	</p><p>网站公告</p>', '81', '1', '1514822460');
INSERT INTO `go_article` VALUES ('18', '142', 'admin', '网站公告标题02', '', '', 'a:0:{}', '', '', '<p>网站公告</p><p><br/></p>', '651', '1', '1514822520');
INSERT INTO `go_article` VALUES ('19', '142', 'admin', '网站公告标题03', '', '', 'a:0:{}', '', '', '<p>&nbsp;网站公告</p>', '74', '1', '1514822760');
INSERT INTO `go_article` VALUES ('20', '142', 'admin', '网站公告标题04', 'color:#FF0000;', '', 'a:0:{}', '', '', '<p>	网站公告</p><p style=\"text-align: center;\"><br/></p><p style=\"text-align: left;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;<br/></p>', '580', '1', '1514822820');
INSERT INTO `go_article` VALUES ('21', '146', 'admin', '官方微信', '', '', 'a:0:{}', '', '', '<p>	</p><p><br/></p><p><br/></p><p style=\"text-align: center;\"><br/></p><p style=\"text-align: center;\"><span style=\"color: rgb(255, 0, 0);\"><strong><span style=\"font-size: 24px;\">微信扫一扫即可关注我们哦！上微信送红包！</span></strong></span></p>', '930', '1', '1514877300');

-- ----------------------------
-- Table structure for `go_brand`
-- ----------------------------
DROP TABLE IF EXISTS `go_brand`;
CREATE TABLE `go_brand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cateid` int(10) unsigned DEFAULT NULL COMMENT '所属栏目ID',
  `status` char(1) DEFAULT 'Y' COMMENT '显示隐藏',
  `name` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `order` (`order`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8 COMMENT='品牌表';

-- ----------------------------
-- Records of go_brand
-- ----------------------------
INSERT INTO `go_brand` VALUES ('1', '5', 'Y', '联想', '16');
INSERT INTO `go_brand` VALUES ('2', '5', 'Y', '诺基亚', '1');
INSERT INTO `go_brand` VALUES ('3', '5', 'Y', '苹果', '1');
INSERT INTO `go_brand` VALUES ('4', '5', 'Y', '三星', '14');
INSERT INTO `go_brand` VALUES ('6', '5', 'Y', '小米', '1');
INSERT INTO `go_brand` VALUES ('7', '5', 'Y', 'oppo', '1');
INSERT INTO `go_brand` VALUES ('8', '5', 'Y', 'HTC', '15');
INSERT INTO `go_brand` VALUES ('10', '6', 'Y', '苹果', '1');
INSERT INTO `go_brand` VALUES ('11', '6', 'Y', '三星', '1');
INSERT INTO `go_brand` VALUES ('12', '6', 'Y', '台电', '13');
INSERT INTO `go_brand` VALUES ('13', '12', 'Y', '尼康', '3');
INSERT INTO `go_brand` VALUES ('14', '6', 'Y', '台电', '1');
INSERT INTO `go_brand` VALUES ('15', '13', 'Y', '尼康', '1');
INSERT INTO `go_brand` VALUES ('16', '5', 'Y', '诺基亚', '1');
INSERT INTO `go_brand` VALUES ('17', '6', 'Y', '苹果', '1');
INSERT INTO `go_brand` VALUES ('18', '6', 'Y', '小米', '1');
INSERT INTO `go_brand` VALUES ('19', '6', 'Y', 'oppo', '1');
INSERT INTO `go_brand` VALUES ('20', '6', 'Y', '海尔', '1');
INSERT INTO `go_brand` VALUES ('21', '6', 'Y', '美的', '1');
INSERT INTO `go_brand` VALUES ('22', '6', 'Y', '华为', '1');
INSERT INTO `go_brand` VALUES ('23', '6', 'Y', '魅族', '1');
INSERT INTO `go_brand` VALUES ('24', '6', 'Y', 'NOKIA', '1');
INSERT INTO `go_brand` VALUES ('25', '6', 'Y', 'VIVO', '1');
INSERT INTO `go_brand` VALUES ('26', '6', 'Y', 'HTC', '1');
INSERT INTO `go_brand` VALUES ('27', '6', 'Y', 'OPPO', '1');
INSERT INTO `go_brand` VALUES ('28', '6', 'Y', 'Lenovo', '1');
INSERT INTO `go_brand` VALUES ('29', '6', 'Y', 'Cannon', '1');
INSERT INTO `go_brand` VALUES ('30', '6', 'Y', 'NiKon', '1');
INSERT INTO `go_brand` VALUES ('31', '6', 'Y', 'Leica', '1');
INSERT INTO `go_brand` VALUES ('32', '6', 'Y', 'SONY', '1');
INSERT INTO `go_brand` VALUES ('33', '6', 'Y', 'FUJIFILM', '1');
INSERT INTO `go_brand` VALUES ('34', '6', 'Y', 'PENT', '1');
INSERT INTO `go_brand` VALUES ('35', '6', 'Y', 'AXPENTAX', '1');
INSERT INTO `go_brand` VALUES ('36', '6', 'Y', '信礼坊', '1');
INSERT INTO `go_brand` VALUES ('37', '6', 'Y', '绿岭', '1');
INSERT INTO `go_brand` VALUES ('38', '5', 'Y', '欧米茄', '1');
INSERT INTO `go_brand` VALUES ('39', '6', 'Y', '礼意久久', '1');
INSERT INTO `go_brand` VALUES ('40', '6', 'Y', '安致儿', '1');
INSERT INTO `go_brand` VALUES ('41', '6', 'Y', '尚艺礼', '1');
INSERT INTO `go_brand` VALUES ('42', '6', 'Y', '梦之草', '1');
INSERT INTO `go_brand` VALUES ('44', '6', 'Y', '红豆', '1');
INSERT INTO `go_brand` VALUES ('45', '6', 'Y', '屋里香', '1');
INSERT INTO `go_brand` VALUES ('46', '6', 'Y', '可蓝', '1');
INSERT INTO `go_brand` VALUES ('47', '6', 'Y', '佳柯', '1');
INSERT INTO `go_brand` VALUES ('48', '6', 'Y', '悠享', '1');
INSERT INTO `go_brand` VALUES ('49', '6', 'Y', '茂霖', '1');
INSERT INTO `go_brand` VALUES ('51', '147', 'Y', '大众', '1');
INSERT INTO `go_brand` VALUES ('52', '147', 'Y', '宝马', '1');
INSERT INTO `go_brand` VALUES ('53', '147', 'Y', '本田', '1');
INSERT INTO `go_brand` VALUES ('54', '147', 'Y', '吉利', '1');
INSERT INTO `go_brand` VALUES ('55', '147', 'Y', '瑞凯威', '1');
INSERT INTO `go_brand` VALUES ('56', '18', 'Y', '德龙', '1');
INSERT INTO `go_brand` VALUES ('57', '14', 'Y', '三星', '1');
INSERT INTO `go_brand` VALUES ('58', '18', 'Y', '中华', '1');
INSERT INTO `go_brand` VALUES ('59', '148', 'Y', '黄金', '1');
INSERT INTO `go_brand` VALUES ('60', '17', 'Y', '充值类', '1');
INSERT INTO `go_brand` VALUES ('61', '14', 'Y', '小米', '1');
INSERT INTO `go_brand` VALUES ('62', '14', 'Y', '苹果', '1');
INSERT INTO `go_brand` VALUES ('63', '15', 'Y', '百莱', '1');
INSERT INTO `go_brand` VALUES ('64', '14', 'Y', '华为', '1');
INSERT INTO `go_brand` VALUES ('65', '14', 'Y', 'OPPO', '1');
INSERT INTO `go_brand` VALUES ('66', '147', 'Y', '屈臣氏', '1');
INSERT INTO `go_brand` VALUES ('67', '149', 'Y', '其他', '1');
INSERT INTO `go_brand` VALUES ('68', '150', 'Y', '年货', '1');

-- ----------------------------
-- Table structure for `go_caches`
-- ----------------------------
DROP TABLE IF EXISTS `go_caches`;
CREATE TABLE `go_caches` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_caches
-- ----------------------------
INSERT INTO `go_caches` VALUES ('1', 'member_name_key', 'admin,administrator');
INSERT INTO `go_caches` VALUES ('2', 'shopcodes_table', '1');
INSERT INTO `go_caches` VALUES ('3', 'goods_count_num', '12330242');
INSERT INTO `go_caches` VALUES ('4', 'template_mobile_reg', '【抢宝在线】您的验证码是：000000。请不要把验证码泄露给其他人。如非本人操作，可不用理会！退订回n');
INSERT INTO `go_caches` VALUES ('5', 'template_mobile_shop', '【抢宝在线】恭喜您参与云购夺宝的商品已获奖！云购夺宝码：00000000，赶快登录账户查看吧！退订回n');
INSERT INTO `go_caches` VALUES ('6', 'template_email_reg', '你好,请在24小时内激活注册邮件，点击连接激活邮件：{地址}');
INSERT INTO `go_caches` VALUES ('7', 'template_email_shop', '恭喜您：{用户名}，你在云购网够买的商品：{商品名称} 已中奖，中奖码是:{中奖码}');
INSERT INTO `go_caches` VALUES ('8', 'pay_bank_type', 'yeepay');

-- ----------------------------
-- Table structure for `go_card_pwd`
-- ----------------------------
DROP TABLE IF EXISTS `go_card_pwd`;
CREATE TABLE `go_card_pwd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pwd` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pwd` (`pwd`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='卡密密码表';

-- ----------------------------
-- Records of go_card_pwd
-- ----------------------------
INSERT INTO `go_card_pwd` VALUES ('1', '4297f44b13955235245b2497399d7a93');

-- ----------------------------
-- Table structure for `go_card_recharge`
-- ----------------------------
DROP TABLE IF EXISTS `go_card_recharge`;
CREATE TABLE `go_card_recharge` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT NULL COMMENT '用户id',
  `money` int(10) unsigned DEFAULT NULL COMMENT '卡密金额',
  `code` varchar(21) DEFAULT NULL COMMENT '卡号',
  `codepwd` varchar(20) DEFAULT NULL COMMENT '卡号密码',
  `isrepeat` varchar(1) DEFAULT 'N' COMMENT '是否一次性',
  `rechargecount` int(10) DEFAULT '0' COMMENT '充值次数',
  `maxrechargecout` int(10) DEFAULT '0' COMMENT '多最可重复多少次',
  `rechargetime` int(10) DEFAULT NULL COMMENT '充值期限',
  `time` int(10) DEFAULT NULL COMMENT '充值时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='卡密表';

-- ----------------------------
-- Records of go_card_recharge
-- ----------------------------

-- ----------------------------
-- Table structure for `go_category`
-- ----------------------------
DROP TABLE IF EXISTS `go_category`;
CREATE TABLE `go_category` (
  `cateid` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '栏目id',
  `parentid` smallint(6) DEFAULT NULL COMMENT '父ID',
  `channel` tinyint(4) NOT NULL DEFAULT '0',
  `model` tinyint(1) DEFAULT NULL COMMENT '栏目模型',
  `name` varchar(255) DEFAULT NULL COMMENT '栏目名称',
  `catdir` char(20) DEFAULT NULL COMMENT '英文名',
  `pic_url` char(200) NOT NULL DEFAULT '' COMMENT '分类图片url',
  `url` varchar(255) DEFAULT NULL,
  `info` text,
  `order` smallint(6) unsigned DEFAULT '1' COMMENT '排序',
  PRIMARY KEY (`cateid`),
  KEY `name` (`name`),
  KEY `order` (`order`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8 COMMENT='栏目表';

-- ----------------------------
-- Records of go_category
-- ----------------------------
INSERT INTO `go_category` VALUES ('1', '0', '0', '2', '帮助', 'help', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";N;s:7:\"content\";N;s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('2', '1', '0', '2', '新手指南', 'xinshouzhinan', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";N;s:7:\"content\";N;s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('3', '1', '0', '2', '购物保障', 'yunbaozhang', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";N;s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('4', '1', '0', '2', '商品配送', 'peisong', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";N;s:7:\"content\";N;s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('5', '0', '0', '1', '儿童玩具', 'ertongwanju', 'cateimg/20150821/22411143158430.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20150821/22411143158430.png\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:12:\"钟表首饰\";s:13:\"meta_keywords\";s:12:\"钟表首饰\";s:16:\"meta_description\";s:12:\"钟表首饰\";}', '2');
INSERT INTO `go_category` VALUES ('7', '0', '0', '-1', '新手指南', 'newbie', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:22:\"single_web.newbie.html\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('8', '0', '0', '-1', '合作专区', 'business', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:24:\"single_web.business.html\";s:7:\"content\";s:34:\"<p>输入栏目内容...567678</p>\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('9', '0', '0', '-1', '公益基金', 'fund', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:20:\"single_web.fund.html\";s:7:\"content\";s:28:\"<p>输入栏目内容...</p>\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('10', '0', '0', '-1', '商城QQ群', 'qqgroup', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:23:\"single_web.qqgroup.html\";s:7:\"content\";s:48:\"PHA+5aaD5a2Q6L6T5YWl5qCP55uu5YaF5a65Li4uPC9wPg==\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('11', '0', '0', '-1', '邀请注册', 'pleasereg', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:25:\"single_web.pleasereg.html\";s:7:\"content\";s:28:\"<p>输入栏目内容...</p>\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('12', '0', '0', '1', '家用电器', 'jydq', 'cateimg/20150821/83980735158378.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20150821/83980735158378.png\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:12:\"数码相机\";s:13:\"meta_keywords\";s:12:\"数码相机\";s:16:\"meta_description\";s:12:\"数码相机\";}', '3');
INSERT INTO `go_category` VALUES ('13', '0', '0', '1', '交通工具', 'diannao', 'cateimg/20150821/71565047158359.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20150821/71565047158359.png\";s:3:\"des\";s:6:\"汽车\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:6:\"电脑\";s:13:\"meta_keywords\";s:6:\"电脑\";s:16:\"meta_description\";s:6:\"电脑\";}', '5');
INSERT INTO `go_category` VALUES ('14', '0', '0', '1', '手机电脑', 'shouji', 'cateimg/20150821/93917600158092.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20150821/93917600158092.png\";s:3:\"des\";s:12:\"手机平板\";s:8:\"template\";N;s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '6');
INSERT INTO `go_category` VALUES ('15', '0', '0', '1', '珠宝首饰', 'qitashangpin', 'cateimg/20150821/81212741158754.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20150821/81212741158754.png\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:12:\"其他商品\";s:13:\"meta_keywords\";s:12:\"其他商品\";s:16:\"meta_description\";s:12:\"其他商品\";}', '9');
INSERT INTO `go_category` VALUES ('16', '1', '0', '2', '商城基金', 'fund', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('18', '0', '0', '1', '音响配饰', 'dnbg', 'cateimg/20150821/22065264158707.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20150821/22065264158707.png\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '8');
INSERT INTO `go_category` VALUES ('142', '0', '0', '2', '网站公告', 'wangzhangonggao', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:12:\"网站公告\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:12:\"网站公告\";s:13:\"meta_keywords\";s:12:\"网站公告\";s:16:\"meta_description\";s:12:\"网站公告\";}', '1');
INSERT INTO `go_category` VALUES ('145', '0', '0', '-1', '测试单页', 'ceshi', 'cateimg/20151214/75614537058926.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20151214/75614537058926.png\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:24:\"single_web.business.html\";s:7:\"content\";s:48:\"PHA+6L6T5YWl5qCP55uu5YaF5a65Li4uMTM0NTQ0NDwvcD4=\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('146', '1', '0', '2', '特色服务', 'tsfw', '', '', 'a:7:{s:5:\"thumb\";s:0:\"\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('147', '0', '0', '1', '食品饮料', 'spyl', 'cateimg/20180515/58789132342257.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20180515/58789132342257.png\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');
INSERT INTO `go_category` VALUES ('149', '0', '0', '1', '生活百货', 'shbh', 'cateimg/20180515/71640552342311.png', '', 'a:7:{s:5:\"thumb\";s:35:\"cateimg/20180515/71640552342311.png\";s:3:\"des\";s:0:\"\";s:8:\"template\";s:0:\"\";s:7:\"content\";s:0:\"\";s:10:\"meta_title\";s:0:\"\";s:13:\"meta_keywords\";s:0:\"\";s:16:\"meta_description\";s:0:\"\";}', '1');

-- ----------------------------
-- Table structure for `go_cjcode`
-- ----------------------------
DROP TABLE IF EXISTS `go_cjcode`;
CREATE TABLE `go_cjcode` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` int(10) unsigned NOT NULL,
  `scenename` char(50) NOT NULL DEFAULT '' COMMENT '推广员或者渠道名称',
  `ticket` char(255) NOT NULL DEFAULT '' COMMENT '二维码ticket',
  `time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `total` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总共的关注人数',
  `nownum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扫描关注人数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_cjcode
-- ----------------------------

-- ----------------------------
-- Table structure for `go_cjlist`
-- ----------------------------
DROP TABLE IF EXISTS `go_cjlist`;
CREATE TABLE `go_cjlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `wxid` char(255) NOT NULL DEFAULT '' COMMENT '推广员或者渠道名称',
  `time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `codeid` char(20) NOT NULL DEFAULT '' COMMENT '场景码',
  `come` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0是关注  1是扫描',
  `sum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扫描或者关注次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='场景关注报表';

-- ----------------------------
-- Records of go_cjlist
-- ----------------------------

-- ----------------------------
-- Table structure for `go_config`
-- ----------------------------
DROP TABLE IF EXISTS `go_config`;
CREATE TABLE `go_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `value` mediumtext,
  `zhushi` text,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_config
-- ----------------------------
INSERT INTO `go_config` VALUES ('1', 'web_name', '云购夺宝', '网站名');
INSERT INTO `go_config` VALUES ('2', 'web_key', '云购', '网站关键字');
INSERT INTO `go_config` VALUES ('3', 'web_des', '云购夺宝商城是一种全新的购物方式,是时尚、潮流的风向标,能满足个性、年轻消费者的购物需求。\n', '网站介绍');
INSERT INTO `go_config` VALUES ('4', 'web_path', 'http://cy.yungoucms.cn', '网站地址');
INSERT INTO `go_config` VALUES ('5', 'templates_edit', '1', '是否允许在线编辑模板');
INSERT INTO `go_config` VALUES ('6', 'templates_name', 'teyunbao', '当前模板方案');
INSERT INTO `go_config` VALUES ('7', 'charset', 'utf-8', '网站字符集');
INSERT INTO `go_config` VALUES ('8', 'timezone', 'Asia/Shanghai', '网站时区');
INSERT INTO `go_config` VALUES ('9', 'error', '1', '1、保存错误日志到 cache/error_log.php | 0、在页面直接显示');
INSERT INTO `go_config` VALUES ('10', 'gzip', '0', '是否Gzip压缩后输出,服务器没有gzip请不要启用');
INSERT INTO `go_config` VALUES ('11', 'lang', 'zh-cn', '网站语言包');
INSERT INTO `go_config` VALUES ('12', 'cache', '3600', '默认缓存时间');
INSERT INTO `go_config` VALUES ('13', 'web_off', '1', '网站是否开启');
INSERT INTO `go_config` VALUES ('14', 'web_off_text', '', '关闭原因');
INSERT INTO `go_config` VALUES ('15', 'tablepre', 'QCNf', null);
INSERT INTO `go_config` VALUES ('16', 'index_name', '?', '隐藏首页文件名');
INSERT INTO `go_config` VALUES ('17', 'expstr', '/', 'url分隔符号');
INSERT INTO `go_config` VALUES ('18', 'admindir', 'admin', '后台管理文件夹');
INSERT INTO `go_config` VALUES ('19', 'qq', '1274117743', 'qq');
INSERT INTO `go_config` VALUES ('20', 'cell', '023-67898642', '联系电话');
INSERT INTO `go_config` VALUES ('21', 'web_logo', 'banner/20180611/74089843693175.png', 'logo');
INSERT INTO `go_config` VALUES ('22', 'web_copyright', '韬龙网络-版权所有', '版权');
INSERT INTO `go_config` VALUES ('23', 'web_name_two', '云购', '短网站名');
INSERT INTO `go_config` VALUES ('24', 'qq_qun', '', 'QQ群');
INSERT INTO `go_config` VALUES ('25', 'goods_end_time', '31', '开奖动画秒数(单位秒)');
INSERT INTO `go_config` VALUES ('26', 'xianshi', '1', '手机端限时揭晓是否显示');
INSERT INTO `go_config` VALUES ('27', 'web_verify', '1', '验证码是否开启');
INSERT INTO `go_config` VALUES ('28', 'sendmobile', '0', '发货微信提醒');
INSERT INTO `go_config` VALUES ('29', 'banner', '通知：2018年1月1日起，本商城将更改为购买游戏礼包免费赠专享号码', '公告');

-- ----------------------------
-- Table structure for `go_czk`
-- ----------------------------
DROP TABLE IF EXISTS `go_czk`;
CREATE TABLE `go_czk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `czknum` varchar(12) NOT NULL COMMENT '充值卡号码',
  `password` varchar(12) NOT NULL COMMENT '充值卡密码',
  `mianzhi` int(11) NOT NULL COMMENT '面值',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '使用状态',
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '充值类型 1一次性 2永久',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_czk
-- ----------------------------

-- ----------------------------
-- Table structure for `go_egglotter_award`
-- ----------------------------
DROP TABLE IF EXISTS `go_egglotter_award`;
CREATE TABLE `go_egglotter_award` (
  `award_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `user_id` int(11) DEFAULT NULL COMMENT '用户ID',
  `user_name` varchar(11) DEFAULT NULL COMMENT '用户名字',
  `rule_id` int(11) DEFAULT NULL COMMENT '活动ID',
  `subtime` int(11) DEFAULT NULL COMMENT '中奖时间',
  `spoil_id` int(11) DEFAULT NULL COMMENT '奖品等级',
  PRIMARY KEY (`award_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_egglotter_award
-- ----------------------------

-- ----------------------------
-- Table structure for `go_egglotter_rule`
-- ----------------------------
DROP TABLE IF EXISTS `go_egglotter_rule`;
CREATE TABLE `go_egglotter_rule` (
  `rule_id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(200) DEFAULT NULL,
  `starttime` int(11) DEFAULT NULL COMMENT '活动开始时间',
  `endtime` int(11) DEFAULT NULL COMMENT '活动结束时间',
  `subtime` int(11) DEFAULT NULL COMMENT '活动编辑时间',
  `lotterytype` int(11) DEFAULT NULL COMMENT '抽奖按币分类',
  `lotterjb` int(11) DEFAULT NULL COMMENT '每一次抽奖使用的金币',
  `ruledesc` text COMMENT '规则介绍',
  `startusing` tinyint(4) DEFAULT NULL COMMENT '启用',
  PRIMARY KEY (`rule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_egglotter_rule
-- ----------------------------
INSERT INTO `go_egglotter_rule` VALUES ('1', '100', '1514908800', '1546444800', '1514943857', '1', '10', '1等奖手机，2等奖50元，3等奖，很遗憾没中奖', '1');

-- ----------------------------
-- Table structure for `go_egglotter_spoil`
-- ----------------------------
DROP TABLE IF EXISTS `go_egglotter_spoil`;
CREATE TABLE `go_egglotter_spoil` (
  `spoil_id` int(11) NOT NULL AUTO_INCREMENT,
  `rule_id` int(11) DEFAULT NULL,
  `spoil_name` text COMMENT '名称',
  `spoil_jl` int(11) DEFAULT NULL COMMENT '机率',
  `spoil_dj` int(11) DEFAULT NULL,
  `urlimg` varchar(200) DEFAULT NULL,
  `subtime` int(11) DEFAULT NULL COMMENT '提交时间',
  PRIMARY KEY (`spoil_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_egglotter_spoil
-- ----------------------------

-- ----------------------------
-- Table structure for `go_fund`
-- ----------------------------
DROP TABLE IF EXISTS `go_fund`;
CREATE TABLE `go_fund` (
  `id` int(10) unsigned NOT NULL,
  `fund_off` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `fund_money` decimal(10,2) unsigned NOT NULL,
  `fund_count_money` decimal(12,2) DEFAULT NULL COMMENT '云购基金',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_fund
-- ----------------------------
INSERT INTO `go_fund` VALUES ('1', '1', '0.10', '6784.10');

-- ----------------------------
-- Table structure for `go_link`
-- ----------------------------
DROP TABLE IF EXISTS `go_link`;
CREATE TABLE `go_link` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '友情链接ID',
  `type` tinyint(1) unsigned NOT NULL COMMENT '链接类型',
  `name` char(20) NOT NULL COMMENT '名称',
  `logo` varchar(250) NOT NULL COMMENT '图片',
  `url` varchar(50) NOT NULL COMMENT '地址',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_link
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member`
-- ----------------------------
DROP TABLE IF EXISTS `go_member`;
CREATE TABLE `go_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL DEFAULT '' COMMENT '用户名',
  `email` varchar(50) NOT NULL DEFAULT '' COMMENT '用户邮箱',
  `mobile` char(11) NOT NULL DEFAULT '' COMMENT '用户手机',
  `password` char(32) DEFAULT NULL COMMENT '密码',
  `user_ip` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT 'photo/member.jpg' COMMENT '用户头像',
  `qianming` varchar(255) DEFAULT NULL COMMENT '用户签名',
  `groupid` tinyint(4) unsigned DEFAULT '1' COMMENT '用户权限组',
  `addgroup` varchar(255) DEFAULT NULL COMMENT '用户加入的圈子组1|2|3',
  `money` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '账户金额',
  `emailcode` char(21) DEFAULT '-1' COMMENT '邮箱认证码',
  `mobilecode` char(21) DEFAULT '-1' COMMENT '手机认证码',
  `othercode` tinyint(1) NOT NULL DEFAULT '0' COMMENT '其他认证方式 1为认证通过',
  `passcode` char(21) DEFAULT '-1' COMMENT '找会密码认证码-1,1,码',
  `reg_key` varchar(100) DEFAULT NULL COMMENT '注册参数',
  `score` int(10) unsigned NOT NULL DEFAULT '0',
  `jingyan` int(10) unsigned DEFAULT '0',
  `yaoqing` int(10) unsigned DEFAULT '0' COMMENT '邀请人',
  `band` varchar(255) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `headimg` char(255) NOT NULL DEFAULT '' COMMENT '用户头像，快捷登陆时候的头像',
  `wxid` char(255) DEFAULT '' COMMENT '微信id',
  `typeid` int(10) unsigned DEFAULT '0' COMMENT '注册来源 0电脑端  1 手机端 2微信关注 3快捷登陆QQ 4 微信快捷',
  `auto_user` tinyint(4) DEFAULT '0',
  `level` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- ----------------------------
-- Records of go_member
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_account`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_account`;
CREATE TABLE `go_member_account` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(1) DEFAULT NULL COMMENT '充值1/消费-1',
  `pay` char(20) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL COMMENT '详情',
  `money` mediumint(8) NOT NULL DEFAULT '0' COMMENT '金额',
  `time` char(20) NOT NULL,
  KEY `uid` (`uid`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员账户明细';

-- ----------------------------
-- Records of go_member_account
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_addmoney_record`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_addmoney_record`;
CREATE TABLE `go_member_addmoney_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `code` char(20) NOT NULL,
  `money` decimal(10,2) unsigned NOT NULL,
  `pay_type` char(20) NOT NULL,
  `status` char(20) NOT NULL,
  `time` int(10) NOT NULL,
  `score` int(10) unsigned NOT NULL DEFAULT '0',
  `scookies` text COMMENT '购物车cookie',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_member_addmoney_record
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_band`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_band`;
CREATE TABLE `go_member_band` (
  `b_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `b_uid` int(10) DEFAULT NULL COMMENT '用户ID',
  `b_type` char(10) DEFAULT NULL COMMENT '绑定登陆类型',
  `b_code` varchar(100) DEFAULT NULL COMMENT '返回数据1',
  `b_data` varchar(100) DEFAULT NULL COMMENT '返回数据2',
  `b_time` int(10) DEFAULT NULL,
  PRIMARY KEY (`b_id`),
  KEY `b_uid` (`b_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_member_band
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_bind_code_record`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_bind_code_record`;
CREATE TABLE `go_member_bind_code_record` (
  `phone` varchar(15) DEFAULT NULL,
  `updatetime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_member_bind_code_record
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_bind_phone`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_bind_phone`;
CREATE TABLE `go_member_bind_phone` (
  `uid` bigint(20) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `intime` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_member_bind_phone
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_cashout`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_cashout`;
CREATE TABLE `go_member_cashout` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `username` varchar(20) NOT NULL COMMENT '开户人',
  `bankname` varchar(255) NOT NULL COMMENT '银行名称',
  `branch` varchar(255) NOT NULL COMMENT '支行',
  `money` decimal(8,0) NOT NULL DEFAULT '0' COMMENT '申请提现金额',
  `time` char(20) NOT NULL COMMENT '申请时间',
  `banknumber` varchar(50) NOT NULL COMMENT '银行帐号',
  `linkphone` varchar(100) NOT NULL COMMENT '联系电话',
  `auditstatus` tinyint(4) NOT NULL COMMENT '1审核通过',
  `procefees` decimal(8,2) NOT NULL COMMENT '手续费',
  `reviewtime` char(20) NOT NULL COMMENT '审核通过时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `type` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='会员账户明细';

-- ----------------------------
-- Records of go_member_cashout
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_del`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_del`;
CREATE TABLE `go_member_del` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL COMMENT '用户名',
  `email` varchar(50) NOT NULL DEFAULT '' COMMENT '用户邮箱',
  `mobile` char(11) NOT NULL DEFAULT '' COMMENT '用户手机',
  `password` char(32) DEFAULT NULL COMMENT '密码',
  `user_ip` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT 'photo/member.jpg' COMMENT '用户头像',
  `qianming` varchar(255) DEFAULT NULL COMMENT '用户签名',
  `groupid` tinyint(4) unsigned DEFAULT '1' COMMENT '用户权限组',
  `addgroup` varchar(255) DEFAULT NULL COMMENT '用户加入的圈子组1|2|3',
  `money` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '账户金额',
  `emailcode` char(21) DEFAULT '-1' COMMENT '邮箱认证码',
  `mobilecode` char(21) DEFAULT '-1' COMMENT '手机认证码',
  `othercode` tinyint(1) NOT NULL DEFAULT '0' COMMENT '其他认证方式 1为认证通过',
  `passcode` char(21) DEFAULT '-1' COMMENT '找会密码认证码-1,1,码',
  `reg_key` varchar(100) DEFAULT NULL COMMENT '注册参数',
  `score` int(10) unsigned NOT NULL DEFAULT '0',
  `jingyan` int(10) unsigned DEFAULT '0',
  `yaoqing` int(10) unsigned DEFAULT '0' COMMENT '邀请人数',
  `band` varchar(255) DEFAULT NULL,
  `time` int(10) DEFAULT NULL,
  `headimg` char(255) NOT NULL DEFAULT '' COMMENT '用户头像，快捷登陆时候的头像',
  `wxid` char(100) DEFAULT '' COMMENT '微信id',
  `typeid` int(10) unsigned DEFAULT '0' COMMENT '注册来源 0电脑端  1 手机端 2微信关注 3快捷登陆QQ 4 微信快捷',
  `auto_user` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- ----------------------------
-- Records of go_member_del
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_dizhi`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_dizhi`;
CREATE TABLE `go_member_dizhi` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `uid` int(10) NOT NULL COMMENT '用户id',
  `sheng` varchar(15) DEFAULT NULL COMMENT '省',
  `shi` varchar(15) DEFAULT NULL COMMENT '市',
  `xian` varchar(15) DEFAULT NULL COMMENT '县',
  `jiedao` varchar(255) DEFAULT NULL COMMENT '街道地址',
  `youbian` mediumint(8) DEFAULT NULL COMMENT '邮编',
  `shouhuoren` varchar(15) DEFAULT NULL COMMENT '收货人',
  `mobile` char(11) DEFAULT NULL COMMENT '手机',
  `tell` varchar(15) DEFAULT NULL COMMENT '座机号',
  `default` char(1) DEFAULT 'N' COMMENT '是否默认',
  `time` int(10) unsigned NOT NULL,
  `qq` char(20) NOT NULL DEFAULT '' COMMENT 'QQ 号码',
  `shifoufahuo` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否发货！',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='会员地址表';

-- ----------------------------
-- Records of go_member_dizhi
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_go_record`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_go_record`;
CREATE TABLE `go_member_go_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(20) DEFAULT NULL COMMENT '订单号',
  `code_tmp` tinyint(3) unsigned DEFAULT NULL COMMENT '相同订单',
  `username` varchar(30) NOT NULL,
  `uphoto` varchar(255) DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL COMMENT '会员id',
  `shopid` int(6) unsigned NOT NULL COMMENT '商品id',
  `shopname` varchar(255) NOT NULL COMMENT '商品名',
  `shopqishu` smallint(6) NOT NULL DEFAULT '0' COMMENT '期数',
  `gonumber` int(10) unsigned DEFAULT NULL COMMENT '购买次数',
  `goucode` longtext NOT NULL COMMENT '云购码',
  `moneycount` decimal(10,2) NOT NULL,
  `huode` char(50) NOT NULL DEFAULT '0' COMMENT '中奖码',
  `pay_type` char(10) DEFAULT NULL COMMENT '付款方式',
  `ip` varchar(255) DEFAULT NULL,
  `status` char(30) DEFAULT NULL COMMENT '订单状态',
  `time` char(21) NOT NULL COMMENT '购买时间',
  `company` char(18) NOT NULL COMMENT '快递单位',
  `company_code` char(20) NOT NULL COMMENT '快递单号',
  `company_money` int(10) unsigned NOT NULL,
  `address` varchar(1024) NOT NULL,
  `order_phone` char(11) NOT NULL,
  `confirm_address` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `shopid` (`shopid`),
  KEY `time` (`time`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='云购记录表';

-- ----------------------------
-- Records of go_member_go_record
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_group`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_group`;
CREATE TABLE `go_member_group` (
  `groupid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(15) NOT NULL COMMENT '会员组名',
  `jingyan_start` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '需要的经验值',
  `jingyan_end` int(10) NOT NULL,
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `type` char(1) NOT NULL DEFAULT 'N' COMMENT '是否是系统组',
  PRIMARY KEY (`groupid`),
  KEY `jingyan` (`jingyan_start`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='会员权限组';

-- ----------------------------
-- Records of go_member_group
-- ----------------------------
INSERT INTO `go_member_group` VALUES ('1', '云购新手', '1', '500', null, 'N');
INSERT INTO `go_member_group` VALUES ('2', '云购小将', '501', '1000', null, 'N');
INSERT INTO `go_member_group` VALUES ('3', '云购中将', '1001', '3000', null, 'N');
INSERT INTO `go_member_group` VALUES ('4', '云购上将', '3001', '6000', null, 'N');
INSERT INTO `go_member_group` VALUES ('5', '云购大将', '6001', '20000', null, 'N');
INSERT INTO `go_member_group` VALUES ('6', '云购将军', '20001', '40000', null, 'N');

-- ----------------------------
-- Table structure for `go_member_message`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_message`;
CREATE TABLE `go_member_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(1) DEFAULT '0' COMMENT '消息来源,0系统,1私信',
  `sendid` int(10) unsigned DEFAULT '0' COMMENT '发送人ID',
  `sendname` char(20) DEFAULT NULL COMMENT '发送人名',
  `content` varchar(255) DEFAULT NULL COMMENT '发送内容',
  `time` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员消息表';

-- ----------------------------
-- Records of go_member_message
-- ----------------------------

-- ----------------------------
-- Table structure for `go_member_recodes`
-- ----------------------------
DROP TABLE IF EXISTS `go_member_recodes`;
CREATE TABLE `go_member_recodes` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(1) NOT NULL COMMENT '收取1//充值-2/提现-3',
  `content` varchar(255) NOT NULL COMMENT '详情',
  `shopid` int(11) DEFAULT NULL COMMENT '商品id',
  `money` decimal(9,3) NOT NULL DEFAULT '0.000' COMMENT '佣金',
  `time` char(20) NOT NULL,
  `ygmoney` decimal(8,2) NOT NULL COMMENT '云购金额',
  `cashoutid` int(11) DEFAULT NULL COMMENT '申请提现记录表id',
  KEY `uid` (`uid`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员账户明细';

-- ----------------------------
-- Records of go_member_recodes
-- ----------------------------

-- ----------------------------
-- Table structure for `go_model`
-- ----------------------------
DROP TABLE IF EXISTS `go_model`;
CREATE TABLE `go_model` (
  `modelid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(10) NOT NULL,
  `table` char(20) NOT NULL,
  PRIMARY KEY (`modelid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='模型表';

-- ----------------------------
-- Records of go_model
-- ----------------------------
INSERT INTO `go_model` VALUES ('1', '云购模型', 'shoplist');
INSERT INTO `go_model` VALUES ('2', '文章模型', 'article');

-- ----------------------------
-- Table structure for `go_navigation`
-- ----------------------------
DROP TABLE IF EXISTS `go_navigation`;
CREATE TABLE `go_navigation` (
  `cid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `type` char(10) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `status` char(1) DEFAULT 'Y' COMMENT '显示/隐藏',
  `order` smallint(6) unsigned DEFAULT '1',
  PRIMARY KEY (`cid`),
  KEY `status` (`status`),
  KEY `order` (`order`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_navigation
-- ----------------------------
INSERT INTO `go_navigation` VALUES ('1', '0', '所有商品', 'index', '/goods_list', 'Y', '5');
INSERT INTO `go_navigation` VALUES ('2', '0', '新手指南', 'foot', '/single/newbie', 'Y', '2');
INSERT INTO `go_navigation` VALUES ('3', '0', '云购夺宝圈子', 'index', '/group', 'Y', '2');
INSERT INTO `go_navigation` VALUES ('4', '0', '关于云购夺宝商城', 'foot', '/help/1', 'Y', '1');
INSERT INTO `go_navigation` VALUES ('5', '0', '隐私声明', 'foot', '/help/12', 'Y', '1');
INSERT INTO `go_navigation` VALUES ('6', '0', '合作专区', 'foot', '/single/business', 'Y', '1');
INSERT INTO `go_navigation` VALUES ('7', '0', '友情链接', 'foot', '/link', 'Y', '1');
INSERT INTO `go_navigation` VALUES ('8', '0', '联系我们', 'foot', '/help/13', 'Y', '1');
INSERT INTO `go_navigation` VALUES ('10', '0', '晒单分享', 'index', '/go/shaidan/', 'Y', '1');
INSERT INTO `go_navigation` VALUES ('13', '0', '邀请好友', 'index', '/single/pleasereg', 'Y', '1');
INSERT INTO `go_navigation` VALUES ('14', '0', '限时获得', 'index', '/go/autolottery', 'Y', '3');
INSERT INTO `go_navigation` VALUES ('16', '0', '最新获得', 'index', '/goods_lottery', 'Y', '4');
INSERT INTO `go_navigation` VALUES ('17', '0', '云购夺宝QQ群', 'foot', '/group_qq', 'Y', '2');

-- ----------------------------
-- Table structure for `go_pay`
-- ----------------------------


-- ----------------------------
-- Records of go_pay
-- ----------------------------


-- ----------------------------
-- Table structure for `go_position`
-- ----------------------------
DROP TABLE IF EXISTS `go_position`;
CREATE TABLE `go_position` (
  `pos_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pos_model` tinyint(3) unsigned NOT NULL,
  `pos_name` varchar(30) NOT NULL,
  `pos_num` tinyint(3) unsigned NOT NULL,
  `pos_maxnum` tinyint(3) unsigned NOT NULL,
  `pos_this_num` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pos_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pos_id`),
  KEY `pos_id` (`pos_id`),
  KEY `pos_model` (`pos_model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_position
-- ----------------------------

-- ----------------------------
-- Table structure for `go_position_data`
-- ----------------------------
DROP TABLE IF EXISTS `go_position_data`;
CREATE TABLE `go_position_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `con_id` int(10) unsigned NOT NULL,
  `mod_id` tinyint(3) unsigned NOT NULL,
  `mod_name` char(20) NOT NULL,
  `pos_id` int(10) unsigned NOT NULL,
  `pos_data` mediumtext NOT NULL,
  `pos_order` int(10) unsigned NOT NULL DEFAULT '1',
  `pos_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_position_data
-- ----------------------------

-- ----------------------------
-- Table structure for `go_qiandao`
-- ----------------------------
DROP TABLE IF EXISTS `go_qiandao`;
CREATE TABLE `go_qiandao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id ?',
  `lianxu` int(4) unsigned NOT NULL DEFAULT '0' COMMENT '???????????',
  `sum` int(4) unsigned NOT NULL DEFAULT '0' COMMENT '??????????',
  `time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '??????',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '???id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of go_qiandao
-- ----------------------------

-- ----------------------------
-- Table structure for `go_qqset`
-- ----------------------------
DROP TABLE IF EXISTS `go_qqset`;
CREATE TABLE `go_qqset` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qq` text CHARACTER SET utf8,
  `name` text CHARACTER SET utf8,
  `type` varchar(30) CHARACTER SET utf8 NOT NULL,
  `qqurl` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `full` char(10) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '???????',
  `province` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `city` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `county` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `subtime` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of go_qqset
-- ----------------------------

-- ----------------------------
-- Table structure for `go_quanzi`
-- ----------------------------
DROP TABLE IF EXISTS `go_quanzi`;
CREATE TABLE `go_quanzi` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` char(15) NOT NULL COMMENT '标题',
  `img` varchar(255) DEFAULT NULL COMMENT '图片地址',
  `chengyuan` mediumint(8) unsigned DEFAULT '0' COMMENT '成员数',
  `tiezi` mediumint(8) unsigned DEFAULT '0' COMMENT '帖子数',
  `guanli` mediumint(8) unsigned NOT NULL COMMENT '管理员',
  `jinhua` smallint(5) unsigned DEFAULT NULL COMMENT '精华帖',
  `jianjie` varchar(255) DEFAULT '暂无介绍' COMMENT '简介',
  `gongao` varchar(255) DEFAULT '暂无' COMMENT '公告',
  `jiaru` char(1) DEFAULT 'Y' COMMENT '申请加入',
  `glfatie` char(1) DEFAULT 'N' COMMENT '发帖权限',
  `time` int(11) NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_quanzi
-- ----------------------------

-- ----------------------------
-- Table structure for `go_quanzi_hueifu`
-- ----------------------------
DROP TABLE IF EXISTS `go_quanzi_hueifu`;
CREATE TABLE `go_quanzi_hueifu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `tzid` int(11) DEFAULT NULL COMMENT '帖子ID匹配',
  `hueifu` text COMMENT '回复内容',
  `hueiyuan` varchar(255) DEFAULT NULL COMMENT '会员',
  `hftime` int(11) DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_quanzi_hueifu
-- ----------------------------

-- ----------------------------
-- Table structure for `go_quanzi_tiezi`
-- ----------------------------
DROP TABLE IF EXISTS `go_quanzi_tiezi`;
CREATE TABLE `go_quanzi_tiezi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `qzid` int(10) unsigned DEFAULT NULL COMMENT '圈子ID匹配',
  `hueiyuan` varchar(255) DEFAULT NULL COMMENT '会员信息',
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `neirong` text COMMENT '内容',
  `hueifu` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '回复',
  `dianji` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '点击量',
  `zhiding` char(1) DEFAULT 'N' COMMENT '置顶',
  `jinghua` char(1) DEFAULT 'N' COMMENT '精华',
  `zuihou` varchar(255) DEFAULT NULL COMMENT '最后回复',
  `time` int(10) unsigned DEFAULT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_quanzi_tiezi
-- ----------------------------

-- ----------------------------
-- Table structure for `go_recom`
-- ----------------------------
DROP TABLE IF EXISTS `go_recom`;
CREATE TABLE `go_recom` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '推荐位id',
  `img` varchar(50) DEFAULT NULL COMMENT '推荐位图片',
  `title` varchar(30) DEFAULT NULL COMMENT '推荐位标题',
  `link` varchar(255) DEFAULT '' COMMENT '链接地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_recom
-- ----------------------------

-- ----------------------------
-- Table structure for `go_reg_money`
-- ----------------------------

-- ----------------------------
-- Records of go_reg_money
-- ----------------------------


-- ----------------------------
-- Table structure for `go_send`
-- ----------------------------
DROP TABLE IF EXISTS `go_send`;
CREATE TABLE `go_send` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned DEFAULT '0',
  `gid` int(11) unsigned DEFAULT '0' COMMENT '商品ID',
  `username` char(50) CHARACTER SET gbk DEFAULT '' COMMENT '用户名',
  `shoptitle` char(120) CHARACTER SET gbk DEFAULT '' COMMENT '商品名称',
  `send_type` tinyint(4) unsigned DEFAULT '0' COMMENT '发送类型',
  `send_time` int(10) unsigned DEFAULT '0' COMMENT '发送时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='中奖信息发送列表';

-- ----------------------------
-- Records of go_send
-- ----------------------------

-- ----------------------------
-- Table structure for `go_shaidan`
-- ----------------------------
DROP TABLE IF EXISTS `go_shaidan`;
CREATE TABLE `go_shaidan` (
  `sd_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '晒单id',
  `sd_userid` int(10) unsigned DEFAULT NULL COMMENT '用户ID',
  `sd_shopid` int(10) unsigned DEFAULT NULL COMMENT '商品ID',
  `sd_qishu` int(10) DEFAULT NULL COMMENT '商品期数',
  `sd_ip` varchar(255) DEFAULT NULL,
  `sd_title` varchar(255) DEFAULT '' COMMENT '晒单标题',
  `sd_thumbs` varchar(255) DEFAULT '' COMMENT '缩略图',
  `sd_content` text COMMENT '晒单内容',
  `sd_photolist` text COMMENT '晒单图片',
  `sd_zhan` int(10) unsigned DEFAULT '0' COMMENT '点赞',
  `sd_ping` int(10) unsigned DEFAULT '0' COMMENT '评论',
  `sd_time` int(10) unsigned DEFAULT NULL COMMENT '晒单时间',
  PRIMARY KEY (`sd_id`),
  KEY `sd_userid` (`sd_userid`),
  KEY `sd_shopid` (`sd_shopid`),
  KEY `sd_zhan` (`sd_zhan`),
  KEY `sd_ping` (`sd_ping`),
  KEY `sd_time` (`sd_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='晒单';

-- ----------------------------
-- Records of go_shaidan
-- ----------------------------

-- ----------------------------
-- Table structure for `go_shaidan_hueifu`
-- ----------------------------
DROP TABLE IF EXISTS `go_shaidan_hueifu`;
CREATE TABLE `go_shaidan_hueifu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sdhf_id` int(11) NOT NULL COMMENT '晒单ID',
  `sdhf_userid` int(11) DEFAULT NULL COMMENT '晒单回复会员ID',
  `sdhf_content` text COMMENT '晒单回复内容',
  `sdhf_time` int(11) DEFAULT NULL,
  `sdhf_username` char(20) DEFAULT NULL,
  `sdhf_img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_shaidan_hueifu
-- ----------------------------

-- ----------------------------
-- Table structure for `go_share`
-- ----------------------------
DROP TABLE IF EXISTS `go_share`;
CREATE TABLE `go_share` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_share
-- ----------------------------

-- ----------------------------
-- Table structure for `go_shopcodes_1`
-- ----------------------------
DROP TABLE IF EXISTS `go_shopcodes_1`;
CREATE TABLE `go_shopcodes_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `s_id` int(10) unsigned NOT NULL,
  `s_cid` smallint(5) unsigned NOT NULL,
  `s_len` smallint(5) DEFAULT NULL,
  `s_codes` text,
  `s_codes_tmp` text,
  PRIMARY KEY (`id`),
  KEY `s_id` (`s_id`),
  KEY `s_cid` (`s_cid`),
  KEY `s_len` (`s_len`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_shopcodes_1
-- ----------------------------

-- ----------------------------
-- Table structure for `go_shoplist`
-- ----------------------------
DROP TABLE IF EXISTS `go_shoplist`;
CREATE TABLE `go_shoplist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `sid` int(10) unsigned NOT NULL COMMENT '同一个商品',
  `cateid` smallint(6) unsigned DEFAULT NULL COMMENT '所属栏目ID',
  `brandid` smallint(6) unsigned DEFAULT NULL COMMENT '所属品牌ID',
  `title` varchar(100) DEFAULT NULL COMMENT '商品标题',
  `title_style` varchar(100) DEFAULT NULL,
  `title2` varchar(100) DEFAULT NULL COMMENT '副标题',
  `keywords` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '金额',
  `yunjiage` decimal(4,2) unsigned DEFAULT '1.00' COMMENT '云购人次价格',
  `zongrenshu` int(10) unsigned DEFAULT '0' COMMENT '总需人数',
  `canyurenshu` int(10) unsigned DEFAULT '0' COMMENT '已参与人数',
  `shenyurenshu` int(10) unsigned DEFAULT NULL,
  `def_renshu` int(10) unsigned DEFAULT '0',
  `qishu` smallint(6) unsigned DEFAULT '0' COMMENT '期数',
  `maxqishu` smallint(5) unsigned DEFAULT '1' COMMENT ' 最大期数',
  `thumb` varchar(255) DEFAULT NULL,
  `picarr` text COMMENT '商品图片',
  `content` mediumtext COMMENT '商品内容详情',
  `codes_table` char(20) DEFAULT NULL,
  `xsjx_time` int(10) unsigned DEFAULT NULL,
  `pos` tinyint(4) unsigned DEFAULT NULL COMMENT '是否推荐',
  `renqi` tinyint(4) unsigned DEFAULT '0' COMMENT '是否人气商品0否1是',
  `time` int(10) unsigned DEFAULT NULL COMMENT '时间',
  `order` int(10) unsigned DEFAULT '1',
  `q_uid` int(10) unsigned DEFAULT NULL COMMENT '中奖人ID',
  `q_user` text NOT NULL COMMENT '中奖人信息',
  `q_user_code` char(20) DEFAULT NULL COMMENT '中奖码',
  `q_content` mediumtext COMMENT '揭晓内容',
  `q_counttime` char(20) DEFAULT NULL COMMENT '总时间相加',
  `q_end_time` char(20) DEFAULT NULL COMMENT '揭晓时间',
  `q_showtime` char(1) DEFAULT 'N' COMMENT 'Y/N揭晓动画',
  `zhiding` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '指定中奖人',
  `goucount` int(32) DEFAULT NULL,
  `buycount` int(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `renqi` (`renqi`),
  KEY `order` (`yunjiage`),
  KEY `q_uid` (`q_uid`),
  KEY `sid` (`sid`),
  KEY `shenyurenshu` (`shenyurenshu`),
  KEY `q_showtime` (`q_showtime`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COMMENT='商品表';

-- ----------------------------
-- Records of go_shoplist
-- ----------------------------

-- ----------------------------
-- Table structure for `go_shoplist_del`
-- ----------------------------
DROP TABLE IF EXISTS `go_shoplist_del`;
CREATE TABLE `go_shoplist_del` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `sid` int(10) unsigned NOT NULL COMMENT '同一个商品',
  `cateid` smallint(6) unsigned DEFAULT NULL COMMENT '所属栏目ID',
  `brandid` smallint(6) unsigned DEFAULT NULL COMMENT '所属品牌ID',
  `title` varchar(100) DEFAULT NULL COMMENT '商品标题',
  `title_style` varchar(100) DEFAULT NULL,
  `title2` varchar(100) DEFAULT NULL COMMENT '副标题',
  `keywords` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `money` decimal(10,2) DEFAULT '0.00' COMMENT '金额',
  `yunjiage` decimal(4,2) unsigned DEFAULT '1.00' COMMENT '云购人次价格',
  `zongrenshu` int(10) unsigned DEFAULT '0' COMMENT '总需人数',
  `canyurenshu` int(10) unsigned DEFAULT '0' COMMENT '已参与人数',
  `shenyurenshu` int(10) unsigned DEFAULT NULL,
  `def_renshu` int(10) unsigned DEFAULT '0',
  `qishu` smallint(6) unsigned DEFAULT '0' COMMENT '期数',
  `maxqishu` smallint(5) unsigned DEFAULT '1' COMMENT ' 最大期数',
  `thumb` varchar(255) DEFAULT NULL,
  `picarr` text COMMENT '商品图片',
  `content` mediumtext COMMENT '商品内容详情',
  `codes_table` char(20) DEFAULT NULL,
  `xsjx_time` int(10) unsigned DEFAULT NULL,
  `pos` tinyint(4) unsigned DEFAULT NULL COMMENT '是否推荐',
  `renqi` tinyint(4) unsigned DEFAULT '0' COMMENT '是否人气商品0否1是',
  `time` int(10) unsigned DEFAULT NULL COMMENT '时间',
  `order` int(10) unsigned DEFAULT '1',
  `q_uid` int(10) unsigned DEFAULT NULL COMMENT '中奖人ID',
  `q_user` text NOT NULL COMMENT '中奖人信息',
  `q_user_code` char(20) DEFAULT NULL COMMENT '中奖码',
  `q_content` mediumtext COMMENT '揭晓内容',
  `q_counttime` char(20) DEFAULT NULL COMMENT '总时间相加',
  `q_end_time` char(20) DEFAULT NULL COMMENT '揭晓时间',
  `q_showtime` char(1) DEFAULT 'N' COMMENT 'Y/N揭晓动画',
  `zhiding` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '指定中奖人',
  `goucount` int(32) DEFAULT NULL,
  `buycount` int(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `renqi` (`renqi`),
  KEY `order` (`yunjiage`),
  KEY `q_uid` (`q_uid`),
  KEY `sid` (`sid`),
  KEY `shenyurenshu` (`shenyurenshu`),
  KEY `q_showtime` (`q_showtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='商品表';

-- ----------------------------
-- Records of go_shoplist_del
-- ----------------------------

-- ----------------------------
-- Table structure for `go_slide`
-- ----------------------------
DROP TABLE IF EXISTS `go_slide`;
CREATE TABLE `go_slide` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(50) DEFAULT NULL COMMENT '幻灯片',
  `title` varchar(30) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `way` int(1) unsigned DEFAULT '0' COMMENT '手机端的轮播图',
  PRIMARY KEY (`id`),
  KEY `img` (`img`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='幻灯片表';

-- ----------------------------
-- Records of go_slide
-- ----------------------------

-- ----------------------------
-- Table structure for `go_template`
-- ----------------------------
DROP TABLE IF EXISTS `go_template`;
CREATE TABLE `go_template` (
  `template_name` char(25) NOT NULL,
  `template` char(25) NOT NULL,
  `des` varchar(100) DEFAULT NULL,
  KEY `template` (`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_template
-- ----------------------------
INSERT INTO `go_template` VALUES ('cart.cartlist.html', 'yungou', '购物车列表');
INSERT INTO `go_template` VALUES ('cart.pay.html', 'yungou', '购物车付款');
INSERT INTO `go_template` VALUES ('cart.paysuccess.html', 'yungou', '购物车支付成功页面');
INSERT INTO `go_template` VALUES ('group.index.html', 'yungou', '圈子首页');
INSERT INTO `go_template` VALUES ('group.list.html', 'yungou', '圈子列表页');
INSERT INTO `go_template` VALUES ('group.nei.html', 'yungou', '圈子内容');
INSERT INTO `go_template` VALUES ('group.right.html', 'yungou', '圈子右边');
INSERT INTO `go_template` VALUES ('help.help.html', 'yungou', '帮助页面');
INSERT INTO `go_template` VALUES ('index.autolottery.html', 'yungou', '限时揭晓');
INSERT INTO `go_template` VALUES ('index.buyrecord.html', 'yungou', '夺宝记录');
INSERT INTO `go_template` VALUES ('index.buyrecordbai.html', 'yungou', '最新夺宝记录');
INSERT INTO `go_template` VALUES ('index.dataserver.html', 'yungou', '已揭晓商品');
INSERT INTO `go_template` VALUES ('index.detail.html', 'yungou', '晒单详情');
INSERT INTO `go_template` VALUES ('index.footer.html', 'yungou', '底部');
INSERT INTO `go_template` VALUES ('index.glist.html', 'yungou', '所有商品');
INSERT INTO `go_template` VALUES ('index.header.html', 'yungou', '头部');
INSERT INTO `go_template` VALUES ('index.index.html', 'yungou', '首页');
INSERT INTO `go_template` VALUES ('index.item.html', 'yungou', '商品展示页');
INSERT INTO `go_template` VALUES ('index.lottery.html', 'yungou', '最新揭晓');
INSERT INTO `go_template` VALUES ('index.shaidan.html', 'yungou', '晒单页面');
INSERT INTO `go_template` VALUES ('link.link.html', 'yungou', '友情链接');
INSERT INTO `go_template` VALUES ('member.address.html', 'yungou', '会员地址添加');
INSERT INTO `go_template` VALUES ('member.cashout.html', 'yungou', '提现申请');
INSERT INTO `go_template` VALUES ('member.commissions.html', 'yungou', '佣金明细');
INSERT INTO `go_template` VALUES ('member.index.html', 'yungou', '会员首页');
INSERT INTO `go_template` VALUES ('member.invitefriends.html', 'yungou', '邀请好友');
INSERT INTO `go_template` VALUES ('member.joingroup.html', 'yungou', '加入的圈子');
INSERT INTO `go_template` VALUES ('member.left.html', 'yungou', '会员中心左边页面');
INSERT INTO `go_template` VALUES ('member.mailchecking.html', 'yungou', '邮箱认证');
INSERT INTO `go_template` VALUES ('member.mobilechecking.htm', 'yungou', '手机认证');
INSERT INTO `go_template` VALUES ('member.mobilesuccess.html', 'yungou', '手机认证成功');
INSERT INTO `go_template` VALUES ('member.modify.html', 'yungou', '会员');
INSERT INTO `go_template` VALUES ('member.orderlist.html', 'yungou', '会员资料');
INSERT INTO `go_template` VALUES ('member.password.html', 'yungou', '会员修改密码');
INSERT INTO `go_template` VALUES ('member.photo.html', 'yungou', '会员修改头像');
INSERT INTO `go_template` VALUES ('member.qqclock.html', 'yungou', '会员QQ绑定');
INSERT INTO `go_template` VALUES ('member.record.html', 'yungou', '提现记录');
INSERT INTO `go_template` VALUES ('member.sendsuccess.html', 'yungou', '邮箱验证发送');
INSERT INTO `go_template` VALUES ('member.sendsuccess2.html', 'yungou', '邮箱验证发送2');
INSERT INTO `go_template` VALUES ('member.shezhi.html', 'yungou', '资料选项卡');
INSERT INTO `go_template` VALUES ('member.singleinsert.html', 'yungou', '会员添加晒单');
INSERT INTO `go_template` VALUES ('member.singlelist.html', 'yungou', '会员晒单');
INSERT INTO `go_template` VALUES ('member.singleupdate.html', 'yungou', '晒单修改');
INSERT INTO `go_template` VALUES ('member.topic.html', 'yungou', '圈子话题');
INSERT INTO `go_template` VALUES ('member.userbalance.html', 'yungou', '账户明细');
INSERT INTO `go_template` VALUES ('member.userbuydetail.html', 'yungou', '夺宝记录');
INSERT INTO `go_template` VALUES ('member.userbuylist.html', 'yungou', '夺宝记录');
INSERT INTO `go_template` VALUES ('member.userfufen.html', 'yungou', '会员福分');
INSERT INTO `go_template` VALUES ('member.userrecharge.html', 'yungou', '账户充值');
INSERT INTO `go_template` VALUES ('search.search.html', 'yungou', '搜索');
INSERT INTO `go_template` VALUES ('single_web.business.html', 'yungou', '单页_合作专区');
INSERT INTO `go_template` VALUES ('single_web.fund.html', 'yungou', '单页_云购基金');
INSERT INTO `go_template` VALUES ('single_web.newbie.html', 'yungou', '单页_新手指南');
INSERT INTO `go_template` VALUES ('single_web.pleasereg.html', 'yungou', '单页_邀请');
INSERT INTO `go_template` VALUES ('single_web.qqgroup.html', 'yungou', '单页_QQ');
INSERT INTO `go_template` VALUES ('system.message.html', 'yungou', '系统消息提示');
INSERT INTO `go_template` VALUES ('us.index.html', 'yungou', '个人主页');
INSERT INTO `go_template` VALUES ('us.left.html', 'yungou', '个人主页左边');
INSERT INTO `go_template` VALUES ('us.tab.html', 'yungou', '个人主页选项');
INSERT INTO `go_template` VALUES ('us.userbuy.html', 'yungou', '个人主页夺宝记录');
INSERT INTO `go_template` VALUES ('us.userpost.html', 'yungou', '个人主页夺宝记录');
INSERT INTO `go_template` VALUES ('us.userraffle.html', 'yungou', '个人主页夺宝记录');
INSERT INTO `go_template` VALUES ('user.emailcheck.html', 'yungou', '邮箱验证');
INSERT INTO `go_template` VALUES ('user.emailok.html', 'yungou', '邮箱验证成功');
INSERT INTO `go_template` VALUES ('user.findemailcheck.html', 'yungou', '找回密码');
INSERT INTO `go_template` VALUES ('user.finderror.html', 'yungou', '邮箱验证已过期');
INSERT INTO `go_template` VALUES ('user.findmobilecheck.html', 'yungou', '手机验证');
INSERT INTO `go_template` VALUES ('user.findok.html', 'yungou', '手机验证成功');
INSERT INTO `go_template` VALUES ('user.findpassword.html', 'yungou', '重置密码');
INSERT INTO `go_template` VALUES ('user.login.html', 'yungou', '会员登录');
INSERT INTO `go_template` VALUES ('user.mobilecheck.html', 'yungou', '手机验证');
INSERT INTO `go_template` VALUES ('user.register.html', 'yungou', '会员注册');
INSERT INTO `go_template` VALUES ('vote.show.html', 'yungou', '投票内容页');
INSERT INTO `go_template` VALUES ('vote.show_total.html', 'yungou', '投票列表');
INSERT INTO `go_template` VALUES ('vote.vote.html', 'yungou', '投票主页');
INSERT INTO `go_template` VALUES ('cart.payend.html', 'yungou', '');
INSERT INTO `go_template` VALUES ('index.header1.html', 'yungou', '');
INSERT INTO `go_template` VALUES ('index.item_animation.html', 'yungou', '');
INSERT INTO `go_template` VALUES ('index.item_contents.html', 'yungou', '');
INSERT INTO `go_template` VALUES ('index.itemifram.html', 'yungou', '');
INSERT INTO `go_template` VALUES ('index.itemiframstory.html', 'yungou', '');
INSERT INTO `go_template` VALUES ('index.qq.html', 'yungou', '');
INSERT INTO `go_template` VALUES ('index.shaidan123.html', 'yungou', '');
INSERT INTO `go_template` VALUES ('member.mobilechecking.htm', 'yungou', '');
INSERT INTO `go_template` VALUES ('mobile', 'yungou', '');
INSERT INTO `go_template` VALUES ('ad.couplet.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('cart.cartlist.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('cart.pay.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('cart.payend.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('cart.paysuccess.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('group.index.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('group.list.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('group.nei.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('group.right.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('help.help.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.autolottery.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.buyrecord.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.buyrecordbai.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.dataserver.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.detail.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.footer.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.glist.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.header.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.header1.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.index.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.item.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.item.html.bak', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.item_animation.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.item_contents.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.itemifram.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.itemiframstory.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.lottery.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.qq.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.shaidan.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('index.shaidan123.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('link.link.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.address.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.cashout.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.commissions.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.index.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.invitefriends.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.joingroup.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.left.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.mailchecking.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.mobilechecking.htm', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.mobilesuccess.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.modify.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.orderlist.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.password.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.photo.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.qqclock.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.record.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.sendsuccess.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.sendsuccess2.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.shezhi.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.singleinsert.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.singlelist.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.singleupdate.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.topic.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.userbalance.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.userbuydetail.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.userbuylist.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.userfufen.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('member.userrecharge.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('mobile', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('search.search.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('single_web.business.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('single_web.fund.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('single_web.newbie.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('single_web.pleasereg.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('single_web.qqgroup.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('system.message.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('us.index.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('us.left.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('us.tab.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('us.userbuy.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('us.userpost.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('us.userraffle.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.emailcheck.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.emailok.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.findemailcheck.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.finderror.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.findmobilecheck.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.findok.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.findpassword.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.login.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.mobilecheck.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('user.register.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('vote.show.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('vote.show_total.html', 'teyunbao', '');
INSERT INTO `go_template` VALUES ('vote.vote.html', 'teyunbao', '');

-- ----------------------------
-- Table structure for `go_vote_activer`
-- ----------------------------
DROP TABLE IF EXISTS `go_vote_activer`;
CREATE TABLE `go_vote_activer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(11) NOT NULL,
  `vote_id` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `ip` char(20) DEFAULT NULL,
  `subtime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_vote_activer
-- ----------------------------

-- ----------------------------
-- Table structure for `go_vote_option`
-- ----------------------------
DROP TABLE IF EXISTS `go_vote_option`;
CREATE TABLE `go_vote_option` (
  `option_id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) DEFAULT NULL,
  `option_title` varchar(100) DEFAULT NULL,
  `option_number` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`option_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_vote_option
-- ----------------------------

-- ----------------------------
-- Table structure for `go_vote_subject`
-- ----------------------------
DROP TABLE IF EXISTS `go_vote_subject`;
CREATE TABLE `go_vote_subject` (
  `vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_title` varchar(100) DEFAULT NULL,
  `vote_starttime` int(11) DEFAULT NULL,
  `vote_endtime` int(11) DEFAULT NULL,
  `vote_sendtime` int(11) DEFAULT NULL,
  `vote_description` text,
  `vote_allowview` tinyint(1) DEFAULT NULL,
  `vote_allowguest` tinyint(1) DEFAULT NULL,
  `vote_interval` int(11) DEFAULT '0',
  `vote_enabled` tinyint(1) DEFAULT NULL,
  `vote_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`vote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_vote_subject
-- ----------------------------

-- ----------------------------
-- Table structure for `go_wap`
-- ----------------------------
DROP TABLE IF EXISTS `go_wap`;
CREATE TABLE `go_wap` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '????',
  `title` char(100) DEFAULT '' COMMENT '????????',
  `link` char(255) DEFAULT '' COMMENT '??????',
  `img` text COMMENT '?????',
  `color` text COMMENT '????????',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of go_wap
-- ----------------------------
INSERT INTO `go_wap` VALUES ('1', '新品推荐', '?/mobile/mobile/glist', 'banner/20180611/73456054689289.jpg', '');
INSERT INTO `go_wap` VALUES ('2', '邀请好友', '?/mobile/user/login', 'banner/20180611/52612304689329.jpg', '');
INSERT INTO `go_wap` VALUES ('3', '新手指南', 'pay/tehui/wf/index.html', 'banner/20180611/86643554689346.jpg', '');
INSERT INTO `go_wap` VALUES ('4', 'Iphone X', '?/mobile/mobile/fen/14', 'banner/20180731/76684777019577.jpg', '');
INSERT INTO `go_wap` VALUES ('5', 'Iphone x未来', '?/mobile/mobile/fen/14', 'banner/20180731/78067810020428.jpg', '');

-- ----------------------------
-- Table structure for `go_wechat_config`
-- ----------------------------
DROP TABLE IF EXISTS `go_wechat_config`;
CREATE TABLE `go_wechat_config` (
  `id` int(1) NOT NULL,
  `token` varchar(100) NOT NULL,
  `appid` char(18) NOT NULL,
  `appsecret` char(32) NOT NULL,
  `access_token` text NOT NULL,
  `dateline` int(10) unsigned NOT NULL,
  `menu` text NOT NULL COMMENT '菜单',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_wechat_config
-- ----------------------------
INSERT INTO `go_wechat_config` VALUES ('1', '1', '2', '3', 'fRcf5ImgIFEy4rOIhMMZgVn9urvz9zrtm1wGmRUSkwijviIuZPJF-boMCuyZel4t5avgBFKKbMMDWn5XYSXwoLEfrvdxUO4zV5KGAgLWsZDq3CESKllIMQkLS68Cff8fXFWgAFADLC', '0', '{\"button\":[{\"name\":\"最新商品\",\"sub_button\":[{\"type\":\"click\",\"name\":\"新品上市\",\"key\":\"new\"},{\"type\":\"click\",\"name\":\"热门推荐\",\"key\":\"tuijian\"},{\"type\":\"click\",\"name\":\"人气商品\",\"key\":\"renqi\"},{\"type\":\"click\",\"name\":\"最新活动\",\"key\":\"xinban\"},{\"type\":\"click\",\"name\":\"快递查询\",\"key\":\"kdcx\"}]},{\"name\":\"会员中心\",\"sub_button\":[{\"type\":\"click\",\"name\":\"积分查询\",\"key\":\"jfcx\"},{\"type\":\"click\",\"name\":\"订单查询\",\"key\":\"ddcx\"},{\"type\":\"click\",\"name\":\"领红包\",\"key\":\"zj\"},{\"type\":\"click\",\"name\":\"会员中心\",\"key\":\"member\"},{\"type\":\"click\",\"name\":\"签到\",\"key\":\"qiandao\"}]},{\"name\":\"更多\",\"sub_button\":[{\"type\":\"view\",\"name\":\"首页\",\"url\":\"http://cziyuan.com/\"},{\"type\":\"click\",\"name\":\"系统介绍\",\"key\":\"hot7\"},{\"type\":\"view\",\"name\":\"去购买\",\"url\":\"http://cziyuan.com/\"},{\"type\":\"click\",\"name\":\"文本消息\",\"key\":\"text\"},{\"type\":\"click\",\"name\":\"使用说明\",\"key\":\"help\"}]}]}');

-- ----------------------------
-- Table structure for `go_weixin_bonus`
-- ----------------------------
DROP TABLE IF EXISTS `go_weixin_bonus`;
CREATE TABLE `go_weixin_bonus` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `type_id` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_weixin_bonus
-- ----------------------------

-- ----------------------------
-- Table structure for `go_weixin_bonus_type`
-- ----------------------------
DROP TABLE IF EXISTS `go_weixin_bonus_type`;
CREATE TABLE `go_weixin_bonus_type` (
  `type_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(60) NOT NULL DEFAULT '',
  `type_money` decimal(10,2) NOT NULL DEFAULT '0.00',
  `send_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `send_start_date` int(11) NOT NULL DEFAULT '0',
  `send_end_date` int(11) NOT NULL DEFAULT '0',
  `total` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '红包总数',
  `getnum` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '领取数量',
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_weixin_bonus_type
-- ----------------------------

-- ----------------------------
-- Table structure for `go_weixin_keywords`
-- ----------------------------
DROP TABLE IF EXISTS `go_weixin_keywords`;
CREATE TABLE `go_weixin_keywords` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `keyword` varchar(100) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '消息类型',
  `contents` text NOT NULL,
  `pic` varchar(80) NOT NULL,
  `pic_tit` varchar(80) NOT NULL,
  `desc` text NOT NULL,
  `pic_url` varchar(80) NOT NULL,
  `count` int(10) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_weixin_keywords
-- ----------------------------

-- ----------------------------
-- Table structure for `go_weixin_point`
-- ----------------------------
DROP TABLE IF EXISTS `go_weixin_point`;
CREATE TABLE `go_weixin_point` (
  `point_id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `point_name` varchar(64) NOT NULL DEFAULT '',
  `point_value` int(3) unsigned NOT NULL,
  `point_num` int(3) NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`point_id`),
  UNIQUE KEY `option_name` (`point_name`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_weixin_point
-- ----------------------------

-- ----------------------------
-- Table structure for `go_weixin_point_record`
-- ----------------------------
DROP TABLE IF EXISTS `go_weixin_point_record`;
CREATE TABLE `go_weixin_point_record` (
  `pr_id` int(7) NOT NULL AUTO_INCREMENT,
  `wxid` char(28) NOT NULL,
  `point_name` varchar(64) NOT NULL,
  `num` int(5) NOT NULL,
  `lasttime` int(10) NOT NULL,
  `datelinie` int(10) NOT NULL,
  `total` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '总共签到次数',
  PRIMARY KEY (`pr_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_weixin_point_record
-- ----------------------------

-- ----------------------------
-- Table structure for `go_weixin_sign`
-- ----------------------------
DROP TABLE IF EXISTS `go_weixin_sign`;
CREATE TABLE `go_weixin_sign` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '????',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '???id\r\n',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '????????',
  `input_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '??????',
  `typeid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '????????',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=gbk COMMENT='?????????????????';

-- ----------------------------
-- Records of go_weixin_sign
-- ----------------------------

-- ----------------------------
-- Table structure for `go_weixin_user`
-- ----------------------------
DROP TABLE IF EXISTS `go_weixin_user`;
CREATE TABLE `go_weixin_user` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `subscribe` tinyint(1) unsigned NOT NULL,
  `wxid` char(28) NOT NULL,
  `nickname` varchar(200) NOT NULL,
  `sex` tinyint(1) unsigned NOT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '领取时间',
  `typeid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '红包的类型id',
  `headimgurl` varchar(200) NOT NULL,
  `subscribe_time` int(10) unsigned NOT NULL,
  `localimgurl` varchar(200) NOT NULL,
  `setp` smallint(2) unsigned NOT NULL,
  `uname` varchar(50) NOT NULL,
  `coupon` varchar(30) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_weixin_user
-- ----------------------------

-- ----------------------------
-- Table structure for `go_wxch_cfg`
-- ----------------------------
DROP TABLE IF EXISTS `go_wxch_cfg`;
CREATE TABLE `go_wxch_cfg` (
  `cfg_id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `cfg_name` varchar(64) NOT NULL DEFAULT '',
  `cfg_value` text NOT NULL COMMENT '参数值',
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`cfg_id`),
  UNIQUE KEY `cfg_name` (`cfg_name`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of go_wxch_cfg
-- ----------------------------
INSERT INTO `go_wxch_cfg` VALUES ('1', 'murl', 'mobile', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('2', 'baseurl', 'http://cy.yungoucms.cn/', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('3', 'imgpath', 'http://cy.yungoucms.cn/statics/uploads/', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('4', 'plustj', 'false', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('5', 'userpwd', '1234567', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('6', 'cxbd', '', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('8', 'oauth', 'true', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('9', 'goods', '', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('10', 'reply', '欢迎关注云购夺宝！\n我们官方网站：www.yungoucms.com\n官网QQ:1274117743\n我们是一个新型的购物平台，旨在提供更加优质的云购服务，是年轻人喜欢的一种购物形式。', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('11', 'share', 'false', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('12', 'money', '0.1', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('13', 'auto', 'a:12:{s:2:\"on\";i:1;s:2:\"uf\";i:10;s:2:\"ul\";i:1990;s:7:\"mintime\";i:5;s:7:\"maxtime\";i:20;s:8:\"maxcount\";s:2:\"10\";s:8:\"mincount\";s:1:\"1\";s:6:\"shopid\";s:313:\"267-266-265-264-263-262-261-260-259-256-254-253-251-248-247-246-243-242-241-215-213-212-211-210-209-208-207-206-146-145-130-129-128-127-126-125-124-123-122-121-110-109-108-107-92-91-90-87-85-84-82-78-77-75-73-72-71-69-68-67-66-65-64-63-49-48-47-46-45-43-42-41-40-39-38-37-36-35-34-33-32-31-30-29-25-19-16-14-13-12\";s:7:\"autoadd\";i:1;s:5:\"mshop\";s:1:\"0\";s:10:\"timeperiod\";s:61:\"0-1-2-3-4-6-5-7-8-9-10-11-12-13-14-15-16-17-18-19-20-21-22-23\";s:7:\"runtime\";i:1528804615;}', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('14', 'template_zj', '-XAsDjl1OMW_GhxLMUkmJRpNDM5369AGF8ApBEpGvtk', 'yes');
INSERT INTO `go_wxch_cfg` VALUES ('15', 'template_fh', 'GghMlORyOnw-aRI4MpeZ56A3JBJTkpWRwfBoTdKjgJo', 'yes');
DELIMITER ;;
CREATE TRIGGER `reg_money` BEFORE INSERT ON `go_member` FOR EACH ROW BEGIN
declare moneys float;
set moneys  = (select money from go_reg_money where id=1);
SET NEW.money = moneys ;
END
;;
DELIMITER ;
DELIMITER ;;
CREATE TRIGGER `reg_add_money_log` AFTER INSERT ON `go_member` FOR EACH ROW BEGIN
INSERT INTO go_member_account (uid,type,pay,content,money,time) values (NEW.uid,1,'账户','注册赠送',NEW.money,unix_timestamp(now()));
END
;;
DELIMITER ;
